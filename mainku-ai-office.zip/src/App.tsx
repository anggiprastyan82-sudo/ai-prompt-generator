import React, { useState } from 'react';
import { 
  NavigationTab, 
  AgentInfo, 
  ActivityItem, 
  Customer, 
  Task, 
  PerformanceReport, 
  AgentStatus 
} from './types';
import { 
  INITIAL_AGENTS, 
  INITIAL_ACTIVITIES, 
  INITIAL_CUSTOMERS, 
  INITIAL_TASKS, 
  INITIAL_REPORTS 
} from './data/dummyData';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { VirtualOffice } from './components/VirtualOffice';
import { ActivityFeed } from './components/ActivityFeed';
import { AgentStatusCards } from './components/AgentStatusCards';
import { HomeOverview } from './components/views/HomeOverview';
import { TasksView } from './components/views/TasksView';
import { CustomersView } from './components/views/CustomersView';
import { ReportsView } from './components/views/ReportsView';
import { SettingsView } from './components/views/SettingsView';
import { CheckCircle2, Sparkles, X } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('office');
  const [agents, setAgents] = useState<AgentInfo[]>(INITIAL_AGENTS);
  const [activities, setActivities] = useState<ActivityItem[]>(INITIAL_ACTIVITIES);
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [reports] = useState<PerformanceReport[]>(INITIAL_REPORTS);

  // Workflow simulation state
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationToast, setSimulationToast] = useState<{ step: number; text: string } | null>(null);

  // Update an agent's status & activity
  const handleUpdateAgentStatus = (agentId: string, newStatus: AgentStatus, activityText?: string) => {
    let resolvedActivity = activityText;
    
    setAgents(prev => prev.map(ag => {
      if (ag.id === agentId) {
        if (!resolvedActivity) {
          if (newStatus === 'WORKING') {
            resolvedActivity = ag.currentTask 
              ? `⚡ Mengerjakan task: ${ag.currentTask}` 
              : `⚡ Sedang memproses tugas teknis & analisis harian`;
          } else if (newStatus === 'CHATTING') {
            resolvedActivity = ag.currentTask 
              ? `💬 Chatting WhatsApp pelanggan: ${ag.currentTask}` 
              : `💬 Live chat WhatsApp dengan customer & member VIP`;
          } else if (newStatus === 'IDLE') {
            resolvedActivity = `☕ Standby di meja kerja, siap menerima task baru`;
          } else if (newStatus === 'COMPLETED') {
            resolvedActivity = ag.currentTask 
              ? `✓ Task selesai: ${ag.currentTask}` 
              : `✓ Tugas berhasil diselesaikan dengan hasil optimal`;
          } else {
            resolvedActivity = ag.activityText;
          }
        }

        const isNewlyCompleted = newStatus === 'COMPLETED' && ag.status !== 'COMPLETED';

        return {
          ...ag,
          status: newStatus,
          activityText: resolvedActivity || ag.activityText,
          completedTasksToday: isNewlyCompleted ? ag.completedTasksToday + 1 : ag.completedTasksToday,
          currentTask: newStatus === 'IDLE' ? undefined : ag.currentTask
        };
      }
      return ag;
    }));

    // Also record in activities list
    const agent = agents.find(a => a.id === agentId);
    if (agent) {
      const newAct: ActivityItem = {
        id: `act-${Date.now()}`,
        time: 'Baru saja',
        agentId: agent.id,
        agentName: agent.name,
        activity: resolvedActivity || `Status diubah menjadi ${newStatus}`,
        status: newStatus
      };
      setActivities(prev => [newAct, ...prev]);
    }
  };

  // Add new task
  const handleAddTask = (newTaskData: Omit<Task, 'taskId' | 'createdAt'>) => {
    const newId = `TSK-${tasks.length + 101}`;
    const now = new Date();
    const formattedDate = `${String(now.getDate()).padStart(2, '0')} Sep 2026 ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    // Smartly resolve working vs chatting status
    let assignedStatus: AgentStatus = newTaskData.agentWorkingStatus || 'WORKING';
    if (!newTaskData.agentWorkingStatus) {
      const taskLower = newTaskData.task.toLowerCase();
      const isChatRelated = 
        taskLower.includes('chat') || 
        taskLower.includes('whatsapp') || 
        taskLower.includes('wa') || 
        taskLower.includes('hubungi') || 
        taskLower.includes('customer') || 
        taskLower.includes('tiket') || 
        taskLower.includes('komplain') ||
        taskLower.includes('pitching') ||
        newTaskData.agentId === 'customer_service' || 
        newTaskData.agentId === 'sales_membership';
      
      assignedStatus = isChatRelated ? 'CHATTING' : 'WORKING';
    }

    const newTask: Task = {
      ...newTaskData,
      agentWorkingStatus: assignedStatus,
      taskId: newId,
      createdAt: formattedDate
    };

    setTasks(prev => [newTask, ...prev]);

    // Update agent's status to WORKING or CHATTING with current task
    const activeText = assignedStatus === 'CHATTING' 
      ? `💬 Chatting WhatsApp: ${newTaskData.task}`
      : `⚡ Mengerjakan task: ${newTaskData.task}`;

    setAgents(prev => prev.map(ag => {
      if (ag.name.toLowerCase().includes(newTaskData.agent.toLowerCase()) || ag.id === newTaskData.agentId) {
        return {
          ...ag,
          status: assignedStatus,
          activityText: activeText,
          currentTask: newTaskData.task
        };
      }
      return ag;
    }));

    // Add activity log
    const newAct: ActivityItem = {
      id: `act-${Date.now()}`,
      time: 'Baru saja',
      agentId: newTaskData.agentId,
      agentName: newTaskData.agent,
      activity: `${assignedStatus === 'CHATTING' ? '💬 Mulai chatting customer:' : '⚡ Mulai mengerjakan task:'} ${newTaskData.task}`,
      status: assignedStatus
    };
    setActivities(prev => [newAct, ...prev]);
  };

  // Mark task status
  const handleUpdateTaskStatus = (taskId: string, newStatus: Task['status'], directAgentStatus?: AgentStatus) => {
    const taskObj = tasks.find(t => t.taskId === taskId);

    setTasks(prev => prev.map(t => {
      if (t.taskId === taskId) {
        return {
          ...t,
          status: newStatus,
          agentWorkingStatus: directAgentStatus || t.agentWorkingStatus,
          result: newStatus === 'COMPLETED' ? 'Task selesai dikerjakan dengan hasil optimal.' : t.result
        };
      }
      return t;
    }));

    if (taskObj) {
      if (newStatus === 'COMPLETED') {
        // Reward agent and set to COMPLETED
        setAgents(prev => prev.map(ag => {
          if (ag.id === taskObj.agentId) {
            return {
              ...ag,
              status: 'COMPLETED',
              completedTasksToday: ag.completedTasksToday + 1,
              activityText: `✓ Selesai mengerjakan: ${taskObj.task}`
            };
          }
          return ag;
        }));

        const newAct: ActivityItem = {
          id: `act-${Date.now()}`,
          time: 'Baru saja',
          agentId: taskObj.agentId,
          agentName: taskObj.agent,
          activity: `✓ Menyelesaikan task: ${taskObj.task}`,
          status: 'COMPLETED'
        };
        setActivities(prev => [newAct, ...prev]);
      } else if (newStatus === 'IN_PROGRESS') {
        const workingSt = directAgentStatus || taskObj.agentWorkingStatus || 'WORKING';
        setAgents(prev => prev.map(ag => {
          if (ag.id === taskObj.agentId) {
            return {
              ...ag,
              status: workingSt,
              activityText: `${workingSt === 'CHATTING' ? '💬 Chatting' : '⚡ Mengerjakan'}: ${taskObj.task}`,
              currentTask: taskObj.task
            };
          }
          return ag;
        }));
      } else if (newStatus === 'CANCELLED') {
        setAgents(prev => prev.map(ag => {
          if (ag.id === taskObj.agentId) {
            return {
              ...ag,
              status: 'IDLE',
              activityText: '☕ Standby di meja kerja, task dibatalkan'
            };
          }
          return ag;
        }));
      }
    }
  };

  // Manual activity added via right panel
  const handleAddManualActivity = (agentName: string, activityText: string, status: AgentStatus) => {
    const targetAgent = agents.find(a => a.name.toLowerCase() === agentName.toLowerCase()) || agents[0];
    const newAct: ActivityItem = {
      id: `act-${Date.now()}`,
      time: 'Baru saja',
      agentId: targetAgent.id,
      agentName: targetAgent.name,
      activity: activityText,
      status: status
    };

    setActivities(prev => [newAct, ...prev]);

    // Sync agent state
    setAgents(prev => prev.map(a => {
      if (a.id === targetAgent.id) {
        return {
          ...a,
          status,
          activityText
        };
      }
      return a;
    }));
  };

  // Simulate end-to-end AI Workflow
  // OWNER -> AI MANAGER -> TASK -> SALES MEMBERSHIP -> LOG -> VIRTUAL OFFICE UPDATE
  const handleSimulateWorkflow = () => {
    if (isSimulating) return;
    setIsSimulating(true);

    // Step 1: Owner Instruction
    setSimulationToast({
      step: 1,
      text: '👑 Owner memberikan instruksi: "Cari customer potensial untuk membership VIP."'
    });

    // Step 2: AI Manager Thinking & Analyzing Sheet Customer
    setTimeout(() => {
      setAgents(prev => prev.map(a => a.id === 'ai_manager' ? {
        ...a,
        status: 'THINKING',
        activityText: 'Membaca Sheet CUSTOMER & menganalisis leads Sultan MLBB...'
      } : a));

      setSimulationToast({
        step: 2,
        text: '🧠 AI Manager: Membaca Sheet CUSTOMER & menganalisis prioritas Kevin Pratama (Whale).'
      });
    }, 1500);

    // Step 3: AI Manager creates Task for Sales Membership
    setTimeout(() => {
      const newTaskId = `TSK-${tasks.length + 101}`;
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      
      const generatedTask: Task = {
        taskId: newTaskId,
        agent: 'Sales Membership',
        agentId: 'sales_membership',
        task: 'Pitching Member Black VIP ke Kevin Pratama dengan benefit cashback 5%',
        priority: 'URGENT',
        status: 'IN_PROGRESS',
        createdAt: `Hari ini, ${timeStr}`,
        result: 'AI Manager delegasikan penawaran personalisasi'
      };

      setTasks(prev => [generatedTask, ...prev]);

      setAgents(prev => prev.map(a => {
        if (a.id === 'ai_manager') {
          return {
            ...a,
            status: 'WORKING',
            activityText: 'Membuat task baru untuk Sales Membership'
          };
        }
        if (a.id === 'sales_membership') {
          return {
            ...a,
            status: 'CHATTING',
            activityText: 'Menghubungi Kevin Pratama via WhatsApp dengan penawaran VIP',
            currentTask: generatedTask.task
          };
        }
        return a;
      }));

      // Add to Activity Feed
      const act1: ActivityItem = {
        id: `act-${Date.now()}-1`,
        time: 'Baru saja',
        agentId: 'ai_manager',
        agentName: 'AI Manager',
        activity: 'Membuat task baru: Penawaran VIP Black Diamond',
        customer: 'Kevin Pratama',
        status: 'WORKING'
      };

      const act2: ActivityItem = {
        id: `act-${Date.now()}-2`,
        time: 'Baru saja',
        agentId: 'sales_membership',
        agentName: 'Sales Membership',
        activity: 'Menghubungi customer Kevin Pratama',
        customer: 'Kevin Pratama (MLBB)',
        status: 'CHATTING'
      };

      setActivities(prev => [act2, act1, ...prev]);

      setSimulationToast({
        step: 3,
        text: '💰 Sales Membership: Mengambil task, status berubah jadi CHATTING & Virtual Office terupdate!'
      });
    }, 3200);

    // Step 4: Completion
    setTimeout(() => {
      setIsSimulating(false);
      setTimeout(() => {
        setSimulationToast(null);
      }, 4000);
    }, 5000);
  };

  // Follow-up trigger from Customers table
  const handleTriggerFollowUp = (customer: Customer) => {
    setActiveTab('office');
    handleAddTask({
      agent: 'Sales Membership',
      agentId: 'sales_membership',
      task: `Follow up khusus ${customer.nameOfMember}: ${customer.aiRecommendation}`,
      priority: customer.salesPriority,
      status: 'IN_PROGRESS',
      result: 'Sales Membership sedang mengirim pesan follow-up'
    });
  };

  const pendingTasksCount = tasks.filter(t => t.status === 'IN_PROGRESS' || t.status === 'PENDING').length;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#070b14] text-slate-100 selection:bg-[#ff1e42] selection:text-white">
      {/* 1. SIDEBAR KIRI */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        pendingTasksCount={pendingTasksCount}
      />

      {/* Center + Right Main Wrapper */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* 2. HEADER */}
        <Header 
          onSimulateWorkflow={handleSimulateWorkflow}
          isSimulating={isSimulating}
        />

        {/* Dynamic Simulation Toast Banner */}
        {simulationToast && (
          <div className="bg-gradient-to-r from-red-950/90 via-slate-900 to-slate-900 border-b border-[#ff1e42]/60 px-6 py-2.5 flex items-center justify-between text-xs z-30 shadow-md">
            <div className="flex items-center gap-3">
              <Sparkles className="w-4 h-4 text-[#ff1e42] animate-spin" />
              <span className="font-rpg text-white font-semibold">
                [ALUR AI STEP {simulationToast.step}/3]: {simulationToast.text}
              </span>
            </div>
            <button 
              onClick={() => setSimulationToast(null)}
              className="p-1 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Content Area: Split between Main Area and Right Panel (Aktivitas Terbaru) */}
        <div className="flex-1 flex min-h-0 overflow-hidden">
          {/* Main Area based on Active Tab */}
          <main className="flex-1 flex flex-col min-w-0 overflow-y-auto bg-[#070b14]">
            {activeTab === 'home' && (
              <HomeOverview 
                agents={agents}
                tasks={tasks}
                customers={customers}
                onNavigate={setActiveTab}
                onSimulateWorkflow={handleSimulateWorkflow}
                isSimulating={isSimulating}
              />
            )}

            {activeTab === 'office' && (
              <div className="p-4 flex-1 flex flex-col">
                <VirtualOffice 
                  agents={agents}
                  onUpdateAgentStatus={handleUpdateAgentStatus}
                  onAssignQuickTask={(agentId) => {
                    const agent = agents.find(a => a.id === agentId);
                    if (agent) {
                      handleAddTask({
                        agent: agent.name,
                        agentId: agent.id,
                        task: `Tugas Prioritas untuk ${agent.name}`,
                        priority: 'HIGH',
                        status: 'IN_PROGRESS',
                        result: 'Sedang dikerjakan'
                      });
                    }
                  }}
                />
              </div>
            )}

            {activeTab === 'tasks' && (
              <TasksView 
                tasks={tasks}
                onAddTask={handleAddTask}
                onUpdateTaskStatus={handleUpdateTaskStatus}
              />
            )}

            {activeTab === 'customers' && (
              <CustomersView 
                customers={customers}
                onTriggerFollowUp={handleTriggerFollowUp}
              />
            )}

            {activeTab === 'reports' && (
              <ReportsView reports={reports} />
            )}

            {activeTab === 'settings' && (
              <SettingsView />
            )}
          </main>

          {/* 4. PANEL KANAN: "AKTIVITAS TERBARU" */}
          {/* Always visible on medium/large screens for live telemetry */}
          <div className="hidden md:flex flex-col h-full">
            <ActivityFeed 
              activities={activities}
              onAddManualActivity={handleAddManualActivity}
            />
          </div>
        </div>

        {/* 5. BAGIAN BAWAH: AGENT STATUS CARDS */}
        <AgentStatusCards 
          agents={agents}
          onSelectAgent={(agent) => {
            setActiveTab('office');
          }}
          onUpdateStatus={(agentId, status) => {
            handleUpdateAgentStatus(agentId, status);
          }}
        />
      </div>
    </div>
  );
}
