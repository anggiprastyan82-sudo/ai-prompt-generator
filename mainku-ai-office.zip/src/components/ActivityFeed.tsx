import React, { useState } from 'react';
import { 
  Activity, 
  MessageSquare, 
  Zap, 
  CheckCircle2, 
  Hourglass, 
  Cpu, 
  Filter, 
  PlusCircle, 
  Send 
} from 'lucide-react';
import { ActivityItem, AgentStatus } from '../types';

interface ActivityFeedProps {
  activities: ActivityItem[];
  onAddManualActivity: (agentName: string, activityText: string, status: AgentStatus) => void;
}

export const ActivityFeed: React.FC<ActivityFeedProps> = ({ 
  activities,
  onAddManualActivity
}) => {
  const [filterAgent, setFilterAgent] = useState<string>('all');
  const [showQuickForm, setShowQuickForm] = useState<boolean>(false);
  const [newAgent, setNewAgent] = useState<string>('Sales Membership');
  const [newActivity, setNewActivity] = useState<string>('');
  const [newStatus, setNewStatus] = useState<AgentStatus>('CHATTING');

  const filteredActivities = filterAgent === 'all' 
    ? activities 
    : activities.filter(a => a.agentName.toLowerCase().includes(filterAgent.toLowerCase()));

  const getStatusBadge = (status: AgentStatus) => {
    switch (status) {
      case 'IDLE':
        return {
          badge: 'bg-slate-800 text-slate-400 border-slate-700',
          icon: <Hourglass className="w-3 h-3 text-slate-400" />
        };
      case 'THINKING':
        return {
          badge: 'bg-amber-950/80 text-amber-300 border-amber-500/50',
          icon: <Cpu className="w-3 h-3 text-amber-400 animate-spin" />
        };
      case 'WORKING':
        return {
          badge: 'bg-cyan-950/80 text-cyan-300 border-cyan-500/50',
          icon: <Zap className="w-3 h-3 text-cyan-400" />
        };
      case 'CHATTING':
        return {
          badge: 'bg-purple-950/80 text-purple-300 border-purple-500/50',
          icon: <MessageSquare className="w-3 h-3 text-purple-400" />
        };
      case 'COMPLETED':
        return {
          badge: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50',
          icon: <CheckCircle2 className="w-3 h-3 text-emerald-400" />
        };
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActivity.trim()) return;
    onAddManualActivity(newAgent, newActivity, newStatus);
    setNewActivity('');
    setShowQuickForm(false);
  };

  return (
    <div 
      id="activity-feed-panel"
      className="w-84 lg:w-92 bg-[#080d1a] border-l border-slate-800/80 flex flex-col justify-between h-full select-none z-20 shrink-0"
    >
      {/* Panel Header */}
      <div className="p-4 border-b border-slate-800/80 bg-[#0a0f1d]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-[#ff1e42]/10 border border-[#ff1e42]/40 text-[#ff1e42]">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-rpg font-bold tracking-wide text-sm text-white">
                AKTIVITAS TERBARU
              </h2>
              <p className="text-[10px] text-slate-400 font-pixel">
                LIVE AGENT TELEMETRY FEED
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowQuickForm(!showQuickForm)}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            title="Tambah Aktivitas Manual"
          >
            <PlusCircle className="w-4 h-4 text-[#ff1e42]" />
          </button>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 text-[11px] no-scrollbar">
          {['all', 'Manager', 'Sales', 'Creative', 'CS', 'Support'].map((f) => (
            <button
              key={f}
              onClick={() => setFilterAgent(f)}
              className={`px-2.5 py-1 rounded-lg capitalize font-pixel whitespace-nowrap transition-colors ${
                filterAgent === f
                  ? 'bg-[#ff1e42] text-white shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Optional Quick Add Form */}
      {showQuickForm && (
        <form onSubmit={handleFormSubmit} className="p-3 bg-slate-900/95 border-b border-slate-800 text-xs space-y-2">
          <div className="font-pixel text-[10px] text-[#ff1e42]">SIMULASI AKTIVITAS BARU</div>
          <select
            value={newAgent}
            onChange={(e) => setNewAgent(e.target.value)}
            className="w-full px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 text-xs"
          >
            <option value="AI Manager">AI Manager</option>
            <option value="Sales Membership">Sales Membership</option>
            <option value="Sales Promo">Sales Promo</option>
            <option value="Creative Agent">Creative Agent</option>
            <option value="Customer Service">Customer Service</option>
            <option value="Support Hub">Support Hub</option>
          </select>

          <input
            type="text"
            placeholder="Aktivitas (contoh: Menghubungi customer)"
            value={newActivity}
            onChange={(e) => setNewActivity(e.target.value)}
            className="w-full px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 text-xs"
          />

          <div className="flex gap-2">
            <select
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value as AgentStatus)}
              className="flex-1 px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 text-xs"
            >
              <option value="CHATTING">CHATTING</option>
              <option value="WORKING">WORKING</option>
              <option value="THINKING">THINKING</option>
              <option value="COMPLETED">COMPLETED</option>
              <option value="IDLE">IDLE</option>
            </select>

            <button
              type="submit"
              className="px-3 py-1.5 rounded-lg bg-[#ff1e42] text-white font-rpg font-bold flex items-center gap-1 hover:bg-red-600"
            >
              <Send className="w-3 h-3" /> Catat
            </button>
          </div>
        </form>
      )}

      {/* Activity List Stream */}
      <div className="flex-1 p-3 space-y-3 overflow-y-auto">
        {filteredActivities.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500 font-pixel">
            Belum ada aktivitas untuk filter ini
          </div>
        ) : (
          filteredActivities.map((act) => {
            const badge = getStatusBadge(act.status);
            return (
              <div
                key={act.id}
                id={`activity-${act.id}`}
                className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700/80 transition-all duration-200 group"
              >
                {/* Agent Name and Time */}
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-rpg font-bold text-xs text-slate-200 group-hover:text-[#ff1e42] transition-colors">
                    {act.agentName}
                  </span>
                  <span className="text-[10px] text-slate-500 font-pixel">
                    {act.time}
                  </span>
                </div>

                {/* Activity Description */}
                <p className="text-xs text-slate-300 font-medium mb-2 leading-relaxed">
                  {act.activity}
                </p>

                {/* Target Customer (if any) */}
                {act.customer && (
                  <div className="text-[11px] text-slate-400 bg-slate-950/60 px-2 py-1 rounded-md mb-2 border border-slate-800/60 truncate">
                    👤 <span className="text-slate-300">{act.customer}</span>
                  </div>
                )}

                {/* Status Indicator */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[10px]">
                  <span className="text-slate-500 font-pixel">Status:</span>
                  <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-pixel ${badge.badge}`}>
                    {badge.icon}
                    <span>{act.status}</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bottom Live Feed Status */}
      <div className="p-3 bg-[#0a0f1d] border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Realtime Stream Active</span>
        </div>
        <span className="font-pixel text-[10px] text-[#ff1e42]">MAINku.com</span>
      </div>
    </div>
  );
};
