import React from 'react';
import { AgentInfo } from '../types';

interface AgentAvatarProps {
  agent: AgentInfo;
  isInspecting?: boolean;
}

export const AgentAvatar: React.FC<AgentAvatarProps> = ({ agent }) => {
  // Determine accessories and look based on agent ID
  const getAgentLook = () => {
    switch (agent.id) {
      case 'ai_manager':
        return {
          hair: 'bg-indigo-600',
          skin: 'bg-[#fcd34d]',
          shirt: 'bg-indigo-900 border-blue-400',
          accessory: 'border-2 border-cyan-300 bg-cyan-400/20 shadow-[0_0_8px_#38bdf8]', // Cyber Visor
          aura: 'animate-pulse text-blue-400'
        };
      case 'sales_membership':
        return {
          hair: 'bg-amber-700',
          skin: 'bg-[#fed7aa]',
          shirt: 'bg-amber-950 border-amber-400',
          accessory: 'border border-amber-300 bg-amber-400/30 text-amber-200', // Gold VIP
          aura: 'text-amber-400'
        };
      case 'sales_promo':
        return {
          hair: 'bg-red-700',
          skin: 'bg-[#fed7aa]',
          shirt: 'bg-red-950 border-red-500',
          accessory: 'bg-red-600 text-white font-bold', // Promo cap
          aura: 'animate-bounce text-red-500'
        };
      case 'creative_agent':
        return {
          hair: 'bg-teal-600',
          skin: 'bg-[#fcd34d]',
          shirt: 'bg-teal-950 border-teal-400',
          accessory: 'bg-purple-600 rounded-full', // Beret
          aura: 'text-teal-400'
        };
      case 'customer_service':
        return {
          hair: 'bg-emerald-700',
          skin: 'bg-[#fed7aa]',
          shirt: 'bg-emerald-950 border-emerald-400',
          accessory: 'border-2 border-emerald-400 rounded-full', // Headset
          aura: 'text-emerald-400'
        };
      case 'support_hub':
        return {
          hair: 'bg-slate-700',
          skin: 'bg-[#fed7aa]',
          shirt: 'bg-orange-950 border-orange-500',
          accessory: 'border-2 border-orange-400', // Goggles
          aura: 'text-orange-400'
        };
      default:
        return {
          hair: 'bg-slate-600',
          skin: 'bg-[#fed7aa]',
          shirt: 'bg-slate-800 border-slate-600',
          accessory: '',
          aura: ''
        };
    }
  };

  const look = getAgentLook();

  return (
    <div className="relative flex flex-col items-center justify-center select-none">
      {/* Mini cardboard box ear accent on head honoring MAINku mascot */}
      <div className="flex gap-4 -mb-1 z-10">
        <div className="w-2.5 h-2.5 bg-amber-700 rotate-[-15deg] border border-amber-400 rounded-tl-sm shadow-sm" />
        <div className="w-2.5 h-2.5 bg-amber-700 rotate-[15deg] border border-amber-400 rounded-tr-sm shadow-sm" />
      </div>

      {/* Head */}
      <div className={`relative w-12 h-11 rounded-lg ${look.skin} border-2 border-slate-900 shadow-md flex flex-col items-center justify-center overflow-hidden`}>
        {/* Hair */}
        <div className={`absolute top-0 inset-x-0 h-3.5 ${look.hair}`} />

        {/* Eyes & Glasses / Visor */}
        {agent.id === 'ai_manager' ? (
          <div className="relative z-10 w-9 h-3.5 mt-2 bg-cyan-400/30 border border-cyan-400 rounded flex items-center justify-center">
            <span className="font-pixel text-[8px] text-cyan-200 tracking-tighter">AI-CORE</span>
          </div>
        ) : agent.id === 'customer_service' ? (
          <div className="relative z-10 flex items-center justify-between w-9 mt-2">
            <div className="w-1.5 h-2 bg-slate-900 rounded-full" />
            {/* Smile */}
            <div className="w-2 h-1 border-b-2 border-slate-900 rounded-full" />
            <div className="w-1.5 h-2 bg-slate-900 rounded-full" />
            {/* Headset Mic */}
            <div className="absolute -left-1.5 -bottom-1 w-2.5 h-2.5 rounded-full bg-slate-800 border border-emerald-400" />
          </div>
        ) : (
          <div className="relative z-10 flex items-center justify-center gap-2 mt-2">
            <div className="w-1.5 h-2 bg-slate-900 rounded-sm" />
            <div className="w-1.5 h-2 bg-slate-900 rounded-sm" />
          </div>
        )}

        {/* Mouth */}
        {agent.status === 'CHATTING' ? (
          <div className="w-2.5 h-1.5 bg-rose-600 rounded-full animate-bounce mt-0.5" />
        ) : (
          <div className="w-2 h-0.5 bg-slate-800 mt-1" />
        )}
      </div>

      {/* Torso & Shirt */}
      <div className={`w-14 h-9 rounded-b-xl ${look.shirt} border-2 border-t-0 flex items-center justify-center shadow-inner relative`}>
        {/* Desk badge */}
        <span className="text-[10px] font-pixel text-slate-300">
          {agent.icon}
        </span>

        {/* Typing arms animation when WORKING or CHATTING */}
        {(agent.status === 'WORKING' || agent.status === 'CHATTING') && (
          <>
            <div className="absolute -left-1 bottom-1 w-2 h-3 bg-amber-200/80 rounded animate-pulse" />
            <div className="absolute -right-1 bottom-1 w-2 h-3 bg-amber-200/80 rounded animate-pulse" />
          </>
        )}
      </div>
    </div>
  );
};
