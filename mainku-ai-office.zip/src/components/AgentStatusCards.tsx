import React from 'react';
import { 
  CheckCircle2, 
  MessageSquare, 
  Zap, 
  Coffee,
  Hourglass, 
  Cpu 
} from 'lucide-react';
import { AgentInfo, AgentStatus } from '../types';

interface AgentStatusCardsProps {
  agents: AgentInfo[];
  onSelectAgent: (agent: AgentInfo) => void;
  onUpdateStatus: (agentId: string, status: AgentStatus) => void;
}

export const AgentStatusCards: React.FC<AgentStatusCardsProps> = ({ 
  agents,
  onSelectAgent,
  onUpdateStatus 
}) => {
  const getStatusBadge = (status: AgentStatus) => {
    switch (status) {
      case 'IDLE':
        return {
          pill: 'bg-slate-800/90 text-slate-300 border-slate-700',
          dot: 'bg-slate-400',
          icon: <Coffee className="w-2.5 h-2.5" />,
          label: 'IDLE'
        };
      case 'WORKING':
        return {
          pill: 'bg-cyan-950/80 text-cyan-300 border-cyan-500/60 shadow-[0_0_8px_rgba(6,182,212,0.3)]',
          dot: 'bg-cyan-400 animate-pulse',
          icon: <Zap className="w-2.5 h-2.5" />,
          label: 'WORKING'
        };
      case 'CHATTING':
        return {
          pill: 'bg-purple-950/80 text-purple-300 border-purple-500/60 shadow-[0_0_8px_rgba(168,85,247,0.3)]',
          dot: 'bg-purple-400 animate-pulse',
          icon: <MessageSquare className="w-2.5 h-2.5" />,
          label: 'CHATTING'
        };
      case 'COMPLETED':
        return {
          pill: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/60 shadow-[0_0_8px_rgba(16,185,129,0.3)]',
          dot: 'bg-emerald-400',
          icon: <CheckCircle2 className="w-2.5 h-2.5" />,
          label: 'COMPLETED'
        };
      case 'THINKING':
      default:
        return {
          pill: 'bg-amber-950/70 text-amber-300 border-amber-500/50',
          dot: 'bg-amber-400 animate-ping',
          icon: <Cpu className="w-2.5 h-2.5 animate-spin" />,
          label: 'THINKING'
        };
    }
  };

  // Status counts
  const workingCount = agents.filter(a => a.status === 'WORKING').length;
  const chattingCount = agents.filter(a => a.status === 'CHATTING').length;
  const idleCount = agents.filter(a => a.status === 'IDLE').length;
  const completedCount = agents.filter(a => a.status === 'COMPLETED').length;

  return (
    <div id="agent-status-cards-section" className="bg-[#080d1a] border-t border-slate-800/80 p-4 z-10 shrink-0">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <span className="font-rpg font-bold text-xs uppercase tracking-wider text-slate-300">
            KARTU STATUS AGENT (STATUS PENGERJAAN)
          </span>
          <span className="text-[10px] font-pixel px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
            6 WORKSTATIONS
          </span>
        </div>

        {/* 4 Status Counters */}
        <div className="flex items-center gap-2 text-[10px] font-pixel">
          <span className="px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span>WORKING: <strong>{workingCount}</strong></span>
          </span>
          <span className="px-2 py-0.5 rounded-full bg-purple-950/80 text-purple-300 border border-purple-500/40 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
            <span>CHATTING: <strong>{chattingCount}</strong></span>
          </span>
          <span className="px-2 py-0.5 rounded-full bg-slate-900 text-slate-300 border border-slate-700 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
            <span>IDLE: <strong>{idleCount}</strong></span>
          </span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>COMPLETED: <strong>{completedCount}</strong></span>
          </span>
        </div>
      </div>

      {/* Grid of 6 Agent Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {agents.map((agent) => {
          const statusConfig = getStatusBadge(agent.status);

          return (
            <div
              key={agent.id}
              id={`agent-card-${agent.id}`}
              className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all duration-200 flex flex-col justify-between group hover:shadow-lg relative"
              style={{
                borderLeftWidth: '3px',
                borderLeftColor: agent.ledHex
              }}
            >
              <div>
                {/* Top: Icon, Name & Status */}
                <div className="flex items-start justify-between gap-1 mb-1.5">
                  <button
                    onClick={() => onSelectAgent(agent)}
                    className="flex items-center gap-1.5 text-left hover:opacity-80 transition-opacity cursor-pointer"
                  >
                    {agent.avatarImage ? (
                      <img 
                        src={agent.avatarImage} 
                        alt={agent.name} 
                        className="w-5 h-5 rounded-md object-cover border border-slate-700 shrink-0" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <span className="text-base">{agent.icon}</span>
                    )}
                    <h4 className="font-rpg font-bold text-xs text-white truncate max-w-[85px] group-hover:text-[#ff1e42] transition-colors">
                      {agent.name}
                    </h4>
                  </button>
                </div>

                {/* Status Pill */}
                <div className="mb-2 flex items-center justify-between">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[9px] font-pixel ${statusConfig.pill}`}>
                    <span className={`w-1 h-1 rounded-full ${statusConfig.dot}`} />
                    <span>{statusConfig.label}</span>
                  </span>
                  <span className="font-pixel text-[9px] text-emerald-400">
                    {agent.completedTasksToday} done
                  </span>
                </div>

                {/* Activity snapshot */}
                <p className="text-[10px] text-slate-400 line-clamp-2 mb-2 leading-snug">
                  {agent.activityText}
                </p>
              </div>

              {/* Quick Status Control Buttons */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="grid grid-cols-4 gap-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateStatus(agent.id, 'WORKING');
                    }}
                    className={`py-1 rounded text-[8px] font-pixel transition-all cursor-pointer ${
                      agent.status === 'WORKING'
                        ? 'bg-cyan-500 text-slate-950 font-bold shadow-[0_0_6px_rgba(6,182,212,0.6)]'
                        : 'bg-slate-800/80 hover:bg-slate-700 text-cyan-300'
                    }`}
                    title="Set status WORKING"
                  >
                    ⚡ WORK
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateStatus(agent.id, 'CHATTING');
                    }}
                    className={`py-1 rounded text-[8px] font-pixel transition-all cursor-pointer ${
                      agent.status === 'CHATTING'
                        ? 'bg-purple-500 text-white font-bold shadow-[0_0_6px_rgba(168,85,247,0.6)]'
                        : 'bg-slate-800/80 hover:bg-slate-700 text-purple-300'
                    }`}
                    title="Set status CHATTING"
                  >
                    💬 CHAT
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateStatus(agent.id, 'IDLE');
                    }}
                    className={`py-1 rounded text-[8px] font-pixel transition-all cursor-pointer ${
                      agent.status === 'IDLE'
                        ? 'bg-slate-600 text-white font-bold'
                        : 'bg-slate-800/80 hover:bg-slate-700 text-slate-400'
                    }`}
                    title="Set status IDLE"
                  >
                    ☕ IDLE
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpdateStatus(agent.id, 'COMPLETED');
                    }}
                    className={`py-1 rounded text-[8px] font-pixel transition-all cursor-pointer ${
                      agent.status === 'COMPLETED'
                        ? 'bg-emerald-500 text-slate-950 font-bold shadow-[0_0_6px_rgba(16,185,129,0.6)]'
                        : 'bg-slate-800/80 hover:bg-slate-700 text-emerald-300'
                    }`}
                    title="Set status COMPLETED"
                  >
                    ✓ DONE
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
