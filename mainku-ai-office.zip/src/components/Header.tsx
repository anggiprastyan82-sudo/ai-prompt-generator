import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Activity, 
  ShieldCheck, 
  User, 
  Zap, 
  Clock 
} from 'lucide-react';

interface HeaderProps {
  onSimulateWorkflow: () => void;
  isSimulating: boolean;
}

export const Header: React.FC<HeaderProps> = ({ 
  onSimulateWorkflow, 
  isSimulating 
}) => {
  const [timeString, setTimeString] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      setTimeString(`${hours}:${minutes}:${seconds} WIB`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header 
      id="main-office-header"
      className="h-18 bg-[#0a0f1d] border-b border-slate-800/80 px-6 flex items-center justify-between z-20 shrink-0"
    >
      {/* Left: Office Title and Status */}
      <div className="flex items-center gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-lg font-bold font-rpg tracking-wider text-white flex items-center gap-2">
              MAINku AI Office
            </h1>
            
            {/* Status Office: Online */}
            <div 
              id="office-status-badge"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-xs font-semibold"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="font-pixel text-[11px] tracking-wide">STATUS: ONLINE</span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400">
            Pusat Komando Virtual Bisnis Top Up Game • 6 AI Agent Aktif
          </p>
        </div>
      </div>

      {/* Right: Clock, Trigger Workflow Simulation, and Owner Profile */}
      <div className="flex items-center gap-4">
        {/* Simulate AI Workflow Button */}
        <button
          id="btn-simulate-workflow"
          onClick={onSimulateWorkflow}
          disabled={isSimulating}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold font-rpg transition-all duration-300 ${
            isSimulating 
              ? 'bg-[#ff1e42]/20 text-[#ff1e42] border border-[#ff1e42]/40 animate-pulse cursor-wait'
              : 'bg-gradient-to-r from-[#ff1e42] to-red-600 hover:from-red-600 hover:to-[#ff1e42] text-white shadow-[0_0_15px_rgba(255,30,66,0.35)] hover:shadow-[0_0_20px_rgba(255,30,66,0.5)] active:scale-95'
          }`}
          title="Simulasikan instruksi Owner -> AI Manager -> Delegasi Task"
        >
          <Zap className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin text-[#ff1e42]' : 'text-white'}`} />
          <span>{isSimulating ? 'AI Workflow Berjalan...' : 'Simulasi AI Workflow'}</span>
        </button>

        {/* Real-time Digital Clock */}
        <div 
          id="realtime-clock-display"
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-200"
        >
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span className="font-pixel text-xs text-slate-200 tracking-wider">
            {timeString || '00:00:00 WIB'}
          </span>
        </div>

        {/* Profil Owner */}
        <div 
          id="owner-profile-card"
          className="flex items-center gap-3 pl-3 border-l border-slate-800"
        >
          <div className="text-right">
            <div className="flex items-center justify-end gap-1 text-xs font-bold text-slate-200">
              <span>Anggi Pras</span>
              <ShieldCheck className="w-3.5 h-3.5 text-[#ff1e42]" />
            </div>
            <span className="text-[10px] text-slate-400 font-pixel">
              OWNER / BOSS
            </span>
          </div>

          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-800 to-slate-700 border border-[#ff1e42]/50 flex items-center justify-center text-white shadow-md">
              <User className="w-5 h-5 text-slate-300" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-[#0a0f1d] rounded-full" />
          </div>
        </div>
      </div>
    </header>
  );
};
