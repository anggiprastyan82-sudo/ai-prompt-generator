export function MainkuLogo({ size = 'normal' }: { size?: 'normal' | 'compact' | 'large' }) {
  const isCompact = size === 'compact';
  const isLarge = size === 'large';

  return (
    <div id="mainku-logo-container" className="flex items-center gap-3 select-none">
      {/* Cat with Cardboard Box on head and 'M' symbol */}
      <div 
        className={`relative flex items-center justify-center rounded-xl bg-gradient-to-br from-amber-700 to-amber-900 border-2 border-amber-500/80 shadow-lg ${
          isCompact ? 'w-9 h-9' : isLarge ? 'w-14 h-14' : 'w-11 h-11'
        }`}
        style={{
          boxShadow: '0 0 15px rgba(245, 158, 11, 0.4), inset 0 2px 4px rgba(255,255,255,0.2)'
        }}
      >
        {/* Cardboard box flap texture */}
        <div className="absolute top-0 inset-x-0 h-1.5 bg-amber-600/60 border-b border-amber-800/80" />
        <div className="absolute bottom-0 inset-x-0 h-1 bg-amber-950/50" />
        
        {/* Cat ears poking out */}
        <div className="absolute -top-1.5 left-1 w-2.5 h-2.5 bg-slate-800 rotate-[-20deg] border-t-2 border-l-2 border-amber-400 rounded-tl-sm" />
        <div className="absolute -top-1.5 right-1 w-2.5 h-2.5 bg-slate-800 rotate-[20deg] border-t-2 border-r-2 border-amber-400 rounded-tr-sm" />
        
        {/* Center M on the box */}
        <span 
          className={`font-black tracking-tighter text-[#ff1e42] drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] font-rpg ${
            isCompact ? 'text-lg' : isLarge ? 'text-2xl' : 'text-xl'
          }`}
        >
          M
        </span>

        {/* Cat Peeking Eyes inside box cutout */}
        <div className="absolute -bottom-1 flex items-center gap-1.5 bg-slate-900/90 px-1 py-0.5 rounded-full border border-amber-500/50">
          <div className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
          <div className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
        </div>
      </div>

      {/* Brand Text */}
      {!isCompact && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1">
            <span className="font-extrabold tracking-wider text-xl font-rpg text-white drop-shadow-sm">
              MAIN<span className="text-[#ff1e42] font-black drop-shadow-[0_0_8px_rgba(255,30,66,0.6)]">ku</span>
            </span>
            <span className="text-xs px-1.5 py-0.2 font-pixel bg-[#ff1e42]/20 text-[#ff1e42] border border-[#ff1e42]/40 rounded">
              AI
            </span>
          </div>
          <span className="text-[10px] font-medium tracking-widest uppercase text-slate-400">
            Virtual Office
          </span>
        </div>
      )}
    </div>
  );
}
