import React from 'react';
import { AgentInfo, AgentStatus } from '../types';

export type OfficeRole = 'owner' | 'manager' | 'sales_membership' | 'sales_promo' | 'creative' | 'cs';

interface OfficeCharacterProps {
  role: OfficeRole;
  label: string;
  icon: string;
  agent?: AgentInfo;
  onClick: () => void;
  isOwner?: boolean;
}

export const OfficeCharacter: React.FC<OfficeCharacterProps> = ({
  role,
  label,
  icon,
  agent,
  onClick,
  isOwner = false
}) => {
  const status: AgentStatus = isOwner ? 'WORKING' : (agent?.status || 'IDLE');
  const activityText = isOwner 
    ? 'Mengawasi performa sales & operasional MAINku.com' 
    : (agent?.activityText || 'Standby di meja kerja');

  // Status color pill
  const getStatusColor = (s: AgentStatus) => {
    switch (s) {
      case 'WORKING':
        return { dot: 'bg-cyan-400 animate-pulse', text: 'text-cyan-300', bg: 'bg-cyan-950/80 border-cyan-500/40' };
      case 'CHATTING':
        return { dot: 'bg-purple-400 animate-pulse', text: 'text-purple-300', bg: 'bg-purple-950/80 border-purple-500/40' };
      case 'THINKING':
        return { dot: 'bg-amber-400 animate-ping', text: 'text-amber-300', bg: 'bg-amber-950/80 border-amber-500/40' };
      case 'COMPLETED':
        return { dot: 'bg-emerald-400', text: 'text-emerald-300', bg: 'bg-emerald-950/80 border-emerald-500/40' };
      case 'IDLE':
      default:
        return { dot: 'bg-slate-400', text: 'text-slate-400', bg: 'bg-slate-900/80 border-slate-700/40' };
    }
  };

  const statusStyle = getStatusColor(status);

  return (
    <div 
      onClick={onClick}
      className="group relative flex flex-col items-center cursor-pointer select-none transition-transform duration-200 hover:scale-[1.03]"
    >
      {/* 1. AGENT LABEL: Dynamic HTML/CSS Overlay (Black pill with white text & icon, matching reference) */}
      <div className="z-30 mb-1.5 flex flex-col items-center">
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#161c28]/95 hover:bg-[#1f2838] border border-slate-700/80 shadow-[0_4px_12px_rgba(0,0,0,0.6)] backdrop-blur-sm transition-all group-hover:border-[#ff1e42]/60 group-hover:shadow-[0_0_12px_rgba(255,30,66,0.3)]">
          <span className="text-xs">{icon}</span>
          <span className="text-xs font-bold font-rpg tracking-wide text-white whitespace-nowrap">
            {label}
          </span>
          <span className="flex h-2 w-2 relative ml-0.5">
            <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${statusStyle.dot}`} />
            <span className={`relative inline-flex rounded-full h-2 w-2 ${statusStyle.dot}`} />
          </span>
        </div>

        {/* Hover / Active Speech Bubble showing dynamic activityText */}
        <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none absolute -top-10 max-w-[220px] px-2.5 py-1 rounded-lg bg-slate-950/95 border border-slate-700 text-center shadow-2xl z-40">
          <p className="text-[10px] text-slate-200 font-medium leading-tight line-clamp-2">
            "{activityText}"
          </p>
          <div className="absolute left-1/2 -bottom-1 -translate-x-1/2 w-2 h-2 bg-slate-950 rotate-45 border-r border-b border-slate-700" />
        </div>
      </div>

      {/* 2. CHARACTER & WORKSTATION DESK (Illustrated RPG / Isometric Wood Scene) */}
      <div className="relative flex flex-col items-center">
        {/* Office Chair Backrest */}
        <div className="absolute -top-3 w-14 h-16 rounded-t-xl bg-gradient-to-b from-[#1b1e28] to-[#12151e] border border-slate-700/80 shadow-md z-0" />

        {/* Character Figure Sitting on Chair */}
        <div className="relative z-10 flex flex-col items-center -mb-2">
          {/* Hair & Head */}
          <div className="relative flex flex-col items-center">
            {/* Hair Accessories / Headsets */}
            {role === 'cs' && (
              <div className="absolute -top-1 w-12 h-6 border-4 border-slate-200 rounded-t-full z-20" />
            )}
            {role === 'sales_promo' && (
              <div className="absolute -top-1 w-11 h-5 border-3 border-[#ff1e42] rounded-t-full z-20" />
            )}
            {role === 'creative' && (
              <div className="absolute -top-1.5 w-11 h-5 bg-[#181d28] rounded-t-lg border-t-2 border-slate-600 z-20 flex justify-center">
                <div className="w-1.5 h-1.5 bg-amber-400 rounded-full mt-0.5" />
              </div>
            )}

            {/* Hair */}
            <div 
              className={`w-11 h-10 rounded-t-2xl shadow-sm z-10 relative overflow-hidden ${
                role === 'manager' ? 'bg-[#1e1b18]' :
                role === 'sales_promo' ? 'bg-[#271813] w-12 h-13 rounded-b-xl' :
                role === 'cs' ? 'bg-[#3b2317] w-12 h-12 rounded-b-xl' :
                role === 'owner' ? 'bg-[#231b14]' :
                role === 'creative' ? 'bg-[#1a1917]' :
                'bg-[#2c2016]'
              }`}
            >
              {/* Hair highlights / texture */}
              <div className="absolute top-1 left-2 w-4 h-1.5 bg-white/20 rounded-full rotate-[-10deg]" />
            </div>

            {/* Face */}
            <div className="relative -mt-4 w-9 h-7 rounded-b-xl bg-[#fcd8b8] border border-amber-900/40 shadow-inner flex flex-col items-center justify-center z-15">
              {/* Glasses for Manager */}
              {role === 'manager' && (
                <div className="absolute top-1 flex items-center gap-1 z-20">
                  <div className="w-3.5 h-3 border-2 border-slate-900 rounded bg-cyan-200/20" />
                  <div className="w-1 h-0.5 bg-slate-900" />
                  <div className="w-3.5 h-3 border-2 border-slate-900 rounded bg-cyan-200/20" />
                </div>
              )}

              {/* Eyes */}
              <div className="flex items-center gap-2.5 mt-1">
                <div className="w-1.5 h-1.5 bg-slate-900 rounded-full" />
                <div className="w-1.5 h-1.5 bg-slate-900 rounded-full" />
              </div>

              {/* Subtle smile */}
              <div className="w-2 h-0.5 bg-amber-900/60 rounded-full mt-0.5" />

              {/* Headset mic for CS or Sales Promo */}
              {(role === 'cs' || role === 'sales_promo') && (
                <div className="absolute -left-1.5 bottom-1 w-2.5 h-1.5 bg-slate-800 rounded-full border border-slate-600" />
              )}
            </div>
          </div>

          {/* Clothes / Upper Body */}
          <div 
            className={`w-12 h-7 rounded-t-lg -mt-0.5 border border-slate-800 shadow-md flex items-center justify-center ${
              role === 'manager' ? 'bg-[#1b382b]' : // Green cardigan
              role === 'owner' ? 'bg-[#181a20]' : // Dark hoodie
              role === 'sales_promo' ? 'bg-[#31161d]' : // Burgundy outfit
              role === 'sales_membership' ? 'bg-[#222a3a]' : // Blue jacket
              role === 'creative' ? 'bg-[#202026]' : // Black streetwear
              'bg-[#2d221e]' // CS cozy sweater
            }`}
          >
            {/* Inner shirt collar */}
            <div className="w-3 h-2 bg-white/90 rounded-b-sm -mt-2" />
          </div>
        </div>

        {/* 3. WARM WOODEN DESK & ACCESSORIES */}
        <div className="relative z-20 flex flex-col items-center">
          {/* Desk Surface (Warm Brown Wood) */}
          <div 
            className="w-48 sm:w-56 h-14 rounded-lg border-2 border-[#543823] shadow-[0_8px_20px_rgba(0,0,0,0.6)] relative flex items-center justify-between px-3 overflow-visible"
            style={{
              background: 'linear-gradient(to bottom, #7c5535, #5a3c22)',
              boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.25), 0 8px 16px rgba(0,0,0,0.5)'
            }}
          >
            {/* Wood Grain Highlights */}
            <div className="absolute inset-x-0 top-0 h-1 bg-[#936642]/60 rounded-t-sm" />
            <div className="absolute inset-x-0 bottom-0 h-1.5 bg-[#3a2514]/80 rounded-b-sm" />

            {/* Left Desk Prop (Mug, Plant, or Camera) */}
            <div className="flex items-center gap-1.5 z-10">
              {/* Potted desk succulent */}
              <div className="flex flex-col items-center">
                <div className="w-3.5 h-3.5 bg-emerald-600 rounded-full border border-emerald-800 shadow-sm flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                </div>
                <div className="w-3 h-2.5 bg-[#8d5b3a] rounded-b-sm border border-amber-900 shadow-xs" />
              </div>

              {/* Coffee Mug or Drink */}
              {role === 'owner' || role === 'cs' ? (
                <div className="relative flex flex-col items-center">
                  <div className="w-3 h-3.5 bg-slate-100 rounded-sm border border-slate-300 shadow-xs flex items-center justify-center">
                    <div className="w-1.5 h-1 bg-[#4a2e18] rounded-full" />
                  </div>
                  {/* Subtle steam */}
                  <div className="w-1 h-2 bg-white/40 blur-[0.5px] rounded-full -mt-4 animate-pulse" />
                </div>
              ) : role === 'creative' ? (
                /* Camera with lens for Creative */
                <div className="w-4 h-3 bg-slate-900 rounded-xs border border-slate-700 shadow-xs flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full border border-slate-800" />
                </div>
              ) : (
                /* Iced Drink Cup with orange straw */
                <div className="relative flex flex-col items-center">
                  <div className="w-0.5 h-2 bg-amber-400 -mb-0.5" />
                  <div className="w-2.5 h-4 bg-amber-500/80 rounded-b-sm border border-amber-600 shadow-xs" />
                </div>
              )}
            </div>

            {/* Center: Silver Laptop with glowing logo */}
            <div className="flex flex-col items-center z-10">
              {/* Laptop Screen Lid */}
              <div className="w-14 h-9 rounded-t-sm bg-gradient-to-b from-[#cbd5e1] to-[#94a3b8] border border-slate-400 shadow-md flex items-center justify-center relative">
                {/* Glowing Apple / Tech Logo */}
                <div className="w-2 h-2 rounded-full bg-white/95 shadow-[0_0_6px_rgba(255,255,255,0.8)]" />
                {/* Screen bezel & glow */}
                <div className="absolute inset-x-1 bottom-0 h-0.5 bg-cyan-400/80 shadow-[0_0_8px_#38bdf8]" />
              </div>
              {/* Laptop Base / Keyboard */}
              <div className="w-16 h-1 bg-[#64748b] rounded-b-sm shadow-sm" />
            </div>

            {/* Right Desk Prop (Teddy bear, Promo Sign, or Phone stand) */}
            <div className="flex items-center gap-1.5 z-10">
              {role === 'manager' && (
                /* Teddy bear for Manager */
                <div className="w-3.5 h-3.5 rounded-full bg-amber-700 border border-amber-900 shadow-xs flex items-center justify-center">
                  <div className="w-1.5 h-1 bg-amber-200 rounded-full" />
                </div>
              )}

              {role === 'creative' && (
                /* Phone on stand */
                <div className="w-2.5 h-4 bg-slate-950 rounded-xs border border-cyan-400 shadow-xs" />
              )}

              {/* Lantern or notebook */}
              <div className="w-3.5 h-4 bg-amber-400/80 rounded-sm border border-amber-600 shadow-[0_0_8px_rgba(245,158,11,0.5)] flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-amber-100 rounded-full animate-pulse" />
              </div>
            </div>

            {/* Standing Mini Chalkboard specifically for Sales Promosi */}
            {role === 'sales_promo' && (
              <div className="absolute -right-14 -top-6 w-12 h-14 bg-[#1e241e] border-2 border-[#6d4c2b] rounded-sm p-1 shadow-lg flex flex-col items-center justify-center rotate-[3deg] z-20">
                <span className="text-[6px] font-pixel text-amber-300 font-bold leading-tight text-center">
                  PROMO TOP UP GAME
                </span>
                <span className="text-[5px] font-pixel text-[#ff1e42] mt-0.5 animate-pulse">
                  ⚡ 50% OFF
                </span>
                <div className="w-6 h-0.5 bg-amber-400/60 mt-1" />
              </div>
            )}
          </div>

          {/* Wooden Desk Legs & Shadow */}
          <div className="w-44 sm:w-52 h-4 flex justify-between px-2">
            <div className="w-2.5 h-full bg-[#412918] border-r border-[#2d1b0d]" />
            <div className="w-2.5 h-full bg-[#412918] border-l border-[#2d1b0d]" />
          </div>
        </div>

        {/* Cozy Floor Green Rug under desk (matching reference) */}
        <div className="w-56 sm:w-64 h-5 rounded-full bg-[#2a3c2e]/60 border border-[#3e5643]/50 -mt-2 -z-10 shadow-sm" />
      </div>
    </div>
  );
};
