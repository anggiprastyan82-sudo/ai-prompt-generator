import React from 'react';
import { 
  Home, 
  Bot, 
  CheckSquare, 
  Users, 
  BarChart3, 
  Settings, 
  Gamepad2, 
  Wifi, 
  Sparkles 
} from 'lucide-react';
import { NavigationTab } from '../types';
import { MainkuLogo } from './MainkuLogo';

interface SidebarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  pendingTasksCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeTab, 
  setActiveTab,
  pendingTasksCount 
}) => {
  const menuItems: { id: NavigationTab; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-5 h-5" /> },
    { id: 'office', label: 'AI Office', icon: <Bot className="w-5 h-5" />, badge: '6 AGENTS' },
    { id: 'tasks', label: 'Tasks', icon: <CheckSquare className="w-5 h-5" />, badge: pendingTasksCount },
    { id: 'customers', label: 'Customers', icon: <Users className="w-5 h-5" /> },
    { id: 'reports', label: 'Reports', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <aside 
      id="sidebar-navigation"
      className="w-64 bg-[#080d1a] border-r border-slate-800/80 flex flex-col justify-between select-none z-30 shrink-0"
    >
      {/* Top Brand Header */}
      <div>
        <div className="p-5 border-b border-slate-800/80">
          <MainkuLogo />
        </div>

        {/* Business Category Pill */}
        <div className="px-5 py-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs text-slate-400">
            <Gamepad2 className="w-3.5 h-3.5 text-[#ff1e42]" />
            <span>Top Up Game Business</span>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="px-3 py-2 space-y-1">
          {menuItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-btn-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all duration-200 group ${
                  isActive
                    ? 'bg-[#ff1e42]/15 text-white border border-[#ff1e42]/60 shadow-[0_0_15px_rgba(255,30,66,0.25)]'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={`${isActive ? 'text-[#ff1e42]' : 'text-slate-500 group-hover:text-slate-300'}`}>
                    {item.icon}
                  </span>
                  <span className={`font-rpg tracking-wide ${isActive ? 'font-bold' : ''}`}>
                    {item.label}
                  </span>
                </div>

                {item.badge !== undefined && (
                  <span 
                    className={`text-[11px] font-pixel px-2 py-0.5 rounded-md ${
                      isActive 
                        ? 'bg-[#ff1e42] text-white' 
                        : 'bg-slate-800/80 text-slate-400 group-hover:text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Info Card: Google Sheets & Office Status */}
      <div className="p-4 m-3 rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800 text-xs">
        <div className="flex items-center justify-between mb-2">
          <span className="text-slate-400 font-medium">Database Node</span>
          <span className="flex items-center gap-1.5 text-emerald-400 font-pixel text-[10px]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            READY
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mb-2.5">
          Google Sheets Mode: <span className="text-slate-200 font-semibold">Dummy Sync (Phase 1)</span>
        </p>

        <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-500">
          <span className="flex items-center gap-1">
            <Wifi className="w-3 h-3 text-emerald-400" /> Vercel Ready
          </span>
          <span className="text-[#ff1e42] font-semibold flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> v1.0 Alpha
          </span>
        </div>
      </div>
    </aside>
  );
};
