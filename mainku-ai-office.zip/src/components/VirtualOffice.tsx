import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  ShieldCheck, 
  Coffee, 
  Gamepad2, 
  Heart, 
  Crown, 
  CheckCircle2, 
  Clock, 
  MessageSquare, 
  Flame, 
  ChevronRight,
  Maximize2,
  Minimize2,
  Volume2,
  Zap,
  Laptop,
  Play,
  Check,
  Bot
} from 'lucide-react';
import { AgentInfo, AgentStatus } from '../types';
import { AGENT_AVATARS, getAgentAvatar } from '../data/agentAvatars';

interface VirtualOfficeProps {
  agents: AgentInfo[];
  onUpdateAgentStatus: (agentId: string, newStatus: AgentStatus, activityText?: string) => void;
  onAssignQuickTask: (agentId: string) => void;
}

interface HotspotConfig {
  id: string;
  role: 'owner' | 'manager' | 'sales_membership' | 'sales_promo' | 'creative' | 'cs';
  label: string;
  icon: string;
  avatarImage: string;
  defaultSpeech: string;
  leftPercent: number;
  topPercent: number;
  agentId?: string;
  isOwner?: boolean;
}

export const VirtualOffice: React.FC<VirtualOfficeProps> = ({
  agents,
  onUpdateAgentStatus,
  onAssignQuickTask
}) => {
  // Pop-up bubble mode: 'TASK_ONLY' (default: only pop up when actively working on a task, not standby), 'ALL' (force all), or 'OFF'
  const [bubbleMode, setBubbleMode] = useState<'TASK_ONLY' | 'ALL' | 'OFF'>('TASK_ONLY');

  // Currently active / opened popup agent for detailed management
  const [activePopupId, setActivePopupId] = useState<string | null>(null);
  const [hoveredPopupId, setHoveredPopupId] = useState<string | null>(null);
  
  // Full modal view state
  const [fullModalAgent, setFullModalAgent] = useState<AgentInfo | null>(null);
  const [showOwnerModal, setShowOwnerModal] = useState<boolean>(false);
  const [easterEggInfo, setEasterEggInfo] = useState<{ title: string; desc: string; icon: string; left: number; top: number } | null>(null);

  // Agent hotspot positions mapped strictly to the reference illustration coordinates (16:9 ratio)
  const hotspots: HotspotConfig[] = [
    {
      id: 'owner',
      role: 'owner',
      label: 'Owner',
      icon: '👑',
      avatarImage: AGENT_AVATARS.owner,
      defaultSpeech: 'Memantau omset harian & strategi pertumbuhan AI Office 👑',
      leftPercent: 14.8,
      topPercent: 18.5,
      isOwner: true
    },
    {
      id: 'ai_manager',
      role: 'manager',
      label: 'Manager',
      icon: '📊',
      avatarImage: AGENT_AVATARS.ai_manager,
      defaultSpeech: 'Analisis omset harian & delegasi leads VIP ke Sales 📈',
      leftPercent: 45.8,
      topPercent: 12.2,
      agentId: 'ai_manager'
    },
    {
      id: 'sales_membership',
      role: 'sales_membership',
      label: 'Sales Membership',
      icon: '👤',
      avatarImage: AGENT_AVATARS.sales_membership,
      defaultSpeech: 'Chatting WhatsApp Sultan MLBB: promo 1000 Diamond bonus! 💎',
      leftPercent: 34.6,
      topPercent: 48.6,
      agentId: 'sales_membership'
    },
    {
      id: 'sales_promo',
      role: 'sales_promo',
      label: 'Sales Promosi',
      icon: '📣',
      avatarImage: AGENT_AVATARS.sales_promo,
      defaultSpeech: 'Flash Sale 50% Genshin & Free Fire siap meluncur! 🔥',
      leftPercent: 58.2,
      topPercent: 48.6,
      agentId: 'sales_promo'
    },
    {
      id: 'creative_agent',
      role: 'creative',
      label: 'Konten Kreatif',
      icon: '📷',
      avatarImage: AGENT_AVATARS.creative_agent,
      defaultSpeech: 'Exporting visual banner promo 4K & copy Reels TikTok 🎨',
      leftPercent: 34.4,
      topPercent: 70.8,
      agentId: 'creative_agent'
    },
    {
      id: 'customer_service',
      role: 'cs',
      label: 'CS',
      icon: '🎧',
      avatarImage: AGENT_AVATARS.customer_service,
      defaultSpeech: 'Halo kak! ID akun diverifikasi, diamond dikirim kilat ⚡',
      leftPercent: 57.4,
      topPercent: 70.8,
      agentId: 'customer_service'
    }
  ];

  // Status helper styles
  const getStatusStyle = (status: AgentStatus) => {
    switch (status) {
      case 'WORKING':
        return {
          dot: 'bg-cyan-400',
          ping: 'bg-cyan-400',
          text: 'text-cyan-400',
          border: 'border-cyan-500/60',
          bg: 'bg-cyan-950/80',
          glow: 'shadow-[0_0_14px_rgba(6,182,212,0.5)]',
          label: 'MENGERJAKAN TASK'
        };
      case 'CHATTING':
        return {
          dot: 'bg-purple-400',
          ping: 'bg-purple-400',
          text: 'text-purple-400',
          border: 'border-purple-500/60',
          bg: 'bg-purple-950/80',
          glow: 'shadow-[0_0_14px_rgba(168,85,247,0.5)]',
          label: 'SEDANG CHATTING'
        };
      case 'THINKING':
        return {
          dot: 'bg-amber-400',
          ping: 'bg-amber-400',
          text: 'text-amber-400',
          border: 'border-amber-500/60',
          bg: 'bg-amber-950/80',
          glow: 'shadow-[0_0_14px_rgba(245,158,11,0.5)]',
          label: 'BERPIKIR & STRATEGI'
        };
      case 'COMPLETED':
        return {
          dot: 'bg-emerald-400',
          ping: 'bg-emerald-400',
          text: 'text-emerald-400',
          border: 'border-emerald-500/60',
          bg: 'bg-emerald-950/80',
          glow: 'shadow-[0_0_14px_rgba(16,185,129,0.5)]',
          label: 'TASK SELESAI'
        };
      case 'IDLE':
      default:
        return {
          dot: 'bg-slate-400',
          ping: 'bg-slate-400',
          text: 'text-slate-400',
          border: 'border-slate-600/60',
          bg: 'bg-slate-900/80',
          glow: 'shadow-none',
          label: 'STANDBY'
        };
    }
  };

  const getAgentByHotspot = (hotspot: HotspotConfig): AgentInfo | undefined => {
    if (hotspot.isOwner) return undefined;
    return agents.find(a => a.id === hotspot.agentId);
  };

  // Quick Action to simulate all agents into specific statuses
  const handleSetAllStatus = (targetStatus: AgentStatus) => {
    agents.forEach((ag) => {
      let taskMsg = '';

      if (targetStatus === 'WORKING') {
        if (ag.id === 'ai_manager') taskMsg = '⚡ Orkestrasi leads VIP & monitor omset flash sale';
        else if (ag.id === 'sales_membership') taskMsg = '⚡ Analisis paket membership diamond sultan';
        else if (ag.id === 'sales_promo') taskMsg = '⚡ Broadcast flash sale 50% Genshin & FF ke 1.200 player!';
        else if (ag.id === 'creative_agent') taskMsg = '⚡ Rendering video Reels gameplay & banner promo 4K';
        else if (ag.id === 'customer_service') taskMsg = '⚡ Audit & verifikasi transaksi manual Moonton';
        else taskMsg = '⚡ Health check latency API Top Up: 180ms (Normal)';
      } else if (targetStatus === 'CHATTING') {
        if (ag.id === 'ai_manager') taskMsg = '💬 Voice briefing tim sales terkait target kuartal 3';
        else if (ag.id === 'sales_membership') taskMsg = '💬 Chatting WhatsApp Sultan MLBB: promo 1000 Diamond bonus!';
        else if (ag.id === 'sales_promo') taskMsg = '💬 Follow up member via WhatsApp: voucher diskon FF 15%';
        else if (ag.id === 'creative_agent') taskMsg = '💬 Diskusi ide campaign dengan tim promosi';
        else if (ag.id === 'customer_service') taskMsg = '💬 Menjawab 5 antrean tiket live chat WhatsApp';
        else taskMsg = '💬 Koordinasi via Telegram ke supplier gateway Digiflazz';
      } else if (targetStatus === 'IDLE') {
        taskMsg = '☕ Standby di meja kerja, siap menerima task baru dari Owner';
      } else if (targetStatus === 'COMPLETED') {
        taskMsg = '✓ Task selesai dikerjakan dengan hasil optimal & tervalidasi!';
      }

      onUpdateAgentStatus(ag.id, targetStatus, taskMsg);
    });
    if (targetStatus === 'WORKING' || targetStatus === 'CHATTING') {
      if (bubbleMode === 'OFF') {
        setBubbleMode('TASK_ONLY');
      }
    }
  };

  // Status counts
  const workingCount = agents.filter(a => a.status === 'WORKING').length;
  const chattingCount = agents.filter(a => a.status === 'CHATTING').length;
  const idleCount = agents.filter(a => a.status === 'IDLE').length;
  const completedCount = agents.filter(a => a.status === 'COMPLETED').length;

  return (
    <div 
      id="virtual-office-stage" 
      className="flex flex-col h-full bg-[#0a0d14] overflow-hidden rounded-2xl border-2 border-[#3d2a1b] shadow-2xl relative select-none"
    >
      {/* Top Ambient Bar with Controls */}
      <div className="bg-[#121722]/95 backdrop-blur-md px-4 py-2.5 border-b border-[#2a3449] flex flex-wrap items-center justify-between gap-2 z-30">
        <div className="flex items-center gap-2 sm:gap-3">
          <span className="text-amber-400 text-base">👑</span>
          <span className="font-rpg font-bold tracking-wider text-xs sm:text-sm text-[#f6e6d5]">
            MAINku AI Office • Live Animated Agents & Bubble Chat
          </span>
          <span className="hidden lg:inline text-[10px] font-pixel px-2 py-0.5 rounded bg-[#2a1b12] text-amber-300 border border-amber-800/60">
            FOTO REFERENSI ASLI
          </span>
        </div>

        {/* 4 Status Counters Badges */}
        <div className="hidden xl:flex items-center gap-2 text-[10px] font-pixel">
          <span className="px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/50 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span>WORKING: <strong>{workingCount}</strong></span>
          </span>
          <span className="px-2 py-0.5 rounded-full bg-purple-950/80 text-purple-300 border border-purple-500/50 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
            <span>CHATTING: <strong>{chattingCount}</strong></span>
          </span>
          <span className="px-2 py-0.5 rounded-full bg-slate-900 text-slate-400 border border-slate-700 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
            <span>IDLE: <strong>{idleCount}</strong></span>
          </span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/50 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>COMPLETED: <strong>{completedCount}</strong></span>
          </span>
        </div>

        {/* Action Controls & Preset Switchers */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-xs">
          {/* Quick Mode Buttons for All Agents */}
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => handleSetAllStatus('WORKING')}
              className="px-2 py-0.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/50 text-[10px] font-pixel flex items-center gap-1 transition-all cursor-pointer"
              title="Set semua agent ke status WORKING (mengerjakan task teknis)"
            >
              <Zap className="w-3 h-3 text-cyan-400" />
              <span>⚡ WORKING</span>
            </button>

            <button
              onClick={() => handleSetAllStatus('CHATTING')}
              className="px-2 py-0.5 rounded-lg bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-500/50 text-[10px] font-pixel flex items-center gap-1 transition-all cursor-pointer"
              title="Set semua agent ke status CHATTING (chat WhatsApp customer)"
            >
              <MessageSquare className="w-3 h-3 text-purple-400" />
              <span>💬 CHATTING</span>
            </button>

            <button
              onClick={() => handleSetAllStatus('IDLE')}
              className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[10px] font-pixel flex items-center gap-1 transition-all cursor-pointer"
              title="Set semua agent ke status IDLE (standby di meja kerja)"
            >
              <Coffee className="w-3 h-3 text-slate-400" />
              <span>☕ IDLE</span>
            </button>

            <button
              onClick={() => handleSetAllStatus('COMPLETED')}
              className="px-2 py-0.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/50 text-[10px] font-pixel flex items-center gap-1 transition-all cursor-pointer"
              title="Set semua agent ke status COMPLETED (task selesai)"
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>✓ COMPLETED</span>
            </button>
          </div>

          {/* Smart Task Pop-up Mode Controls (Task Only, All, Off) */}
          <div className="flex items-center bg-slate-900/90 rounded-lg p-0.5 border border-slate-700/80 text-xs">
            <button
              onClick={() => setBubbleMode('TASK_ONLY')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-rpg font-semibold transition-all cursor-pointer ${
                bubbleMode === 'TASK_ONLY'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/80 shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Pop-up otomatis muncul saat agent sedang aktif mengerjakan task (Tidak standby)"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>Pop-up: <strong className="text-cyan-300">Saat Task</strong></span>
            </button>

            <button
              onClick={() => setBubbleMode(bubbleMode === 'ALL' ? 'TASK_ONLY' : 'ALL')}
              className={`px-2 py-1 rounded-md text-xs font-rpg transition-all cursor-pointer ${
                bubbleMode === 'ALL'
                  ? 'bg-blue-950 text-blue-300 border border-blue-500/80 shadow-[0_0_10px_rgba(59,130,246,0.4)]'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Tampilkan semua bubble chat sekaligus"
            >
              Semua
            </button>

            <button
              onClick={() => setBubbleMode(bubbleMode === 'OFF' ? 'TASK_ONLY' : 'OFF')}
              className={`px-2 py-1 rounded-md text-xs font-rpg transition-all cursor-pointer ${
                bubbleMode === 'OFF'
                  ? 'bg-slate-800 text-slate-200 border border-slate-600'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Sembunyikan semua pop-up (Hanya muncul saat kursor diarahkan ke meja)"
            >
              Off
            </button>
          </div>
        </div>
      </div>

      {/* Main Isometric Virtual Office Scene Frame */}
      <div 
        className="flex-1 relative overflow-auto p-2 sm:p-4 flex items-center justify-center min-h-[580px]"
        style={{
          backgroundColor: '#0c0f17',
          backgroundImage: `
            radial-gradient(circle at 50% 35%, rgba(255, 30, 66, 0.08) 0%, transparent 60%),
            linear-gradient(to right, rgba(30, 41, 59, 0.25) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(30, 41, 59, 0.25) 1px, transparent 1px)
          `,
          backgroundSize: '100% 100%, 32px 32px, 32px 32px'
        }}
      >
        {/* The Exact Reference Photo Container (16:9 Aspect Ratio) */}
        <div 
          className="relative w-full max-w-6xl aspect-[16/9] min-h-[480px] rounded-2xl shadow-[0_12px_45px_rgba(0,0,0,0.85)] border-4 border-[#523724] overflow-hidden group"
          onClick={() => {
            setEasterEggInfo(null);
          }}
        >
          {/* BASE LAYER: The High-Resolution Reference Office Illustration */}
          <img 
            src="/assets/office_room_bg.jpg" 
            alt="MAINku AI Office Virtual Room"
            className="w-full h-full object-cover select-none pointer-events-none"
            loading="eager"
          />

          {/* ============================================================ */}
          {/* AMBIENT ANIMATIONS OVERLAY ON TOP OF REFERENCE PHOTO */}
          {/* ============================================================ */}

          {/* 1. Aquarium Water Shimmer Glow (Center) */}
          <div 
            className="absolute pointer-events-none rounded-sm opacity-60 mix-blend-screen animate-pulse"
            style={{
              left: '39.5%',
              top: '36.8%',
              width: '14%',
              height: '8.5%',
              background: 'radial-gradient(circle, rgba(56, 189, 248, 0.45) 0%, transparent 70%)',
              boxShadow: '0 0 25px rgba(14, 165, 233, 0.5)'
            }}
          />

          {/* 2. Top-Left Floor Lamp Glow (Owner Area) */}
          <div 
            className="absolute pointer-events-none rounded-full opacity-50 mix-blend-screen"
            style={{
              left: '7.5%',
              top: '11%',
              width: '8%',
              height: '14%',
              background: 'radial-gradient(circle, rgba(251, 191, 36, 0.4) 0%, transparent 70%)',
              animation: 'pulse 3.5s infinite ease-in-out'
            }}
          />

          {/* 3. Top-Center Lamp Glow (Manager Area) */}
          <div 
            className="absolute pointer-events-none rounded-full opacity-40 mix-blend-screen"
            style={{
              left: '58.5%',
              top: '10.5%',
              width: '7%',
              height: '13%',
              background: 'radial-gradient(circle, rgba(251, 191, 36, 0.35) 0%, transparent 70%)',
              animation: 'pulse 4s infinite ease-in-out'
            }}
          />

          {/* 4. Sleeping Cats "z Z z" Floating Animation (Bottom-Left) */}
          <div 
            className="absolute pointer-events-none flex flex-col items-center select-none"
            style={{ left: '9.2%', top: '65%' }}
          >
            <span className="text-[9px] font-pixel text-amber-200 animate-bounce opacity-80" style={{ animationDuration: '2.5s' }}>
              z Z z
            </span>
          </div>

          {/* 5. Coffee Steam Particle Animation (Pantry Top-Right) */}
          <div 
            className="absolute pointer-events-none flex flex-col items-center"
            style={{ left: '67.5%', top: '16%' }}
          >
            <div className="w-1.5 h-3 bg-white/30 rounded-full blur-[1px] animate-pulse" />
          </div>

          {/* ============================================================ */}
          {/* EASTER EGG INTERACTIVE CLICKABLE ZONES */}
          {/* ============================================================ */}

          {/* Aquarium Click Zone */}
          <div 
            onClick={(e) => {
              e.stopPropagation();
              setEasterEggInfo({
                title: 'Aquarium Ikan Hias MAINku',
                desc: 'Habitat relaksasi tim dengan ikan cupang & neon tetra. Memberikan +10% Focus Buff kepada semua agen!',
                icon: '🐠',
                left: 46.5,
                top: 41
              });
            }}
            title="Klik Aquarium untuk relaksasi"
            className="absolute cursor-pointer rounded border border-cyan-400/30 hover:border-cyan-400 hover:shadow-[0_0_15px_rgba(6,182,212,0.6)] transition-all z-20"
            style={{ left: '39%', top: '36.5%', width: '15%', height: '9%' }}
          />

          {/* Sleeping Cats Click Zone */}
          <div 
            onClick={(e) => {
              e.stopPropagation();
              setEasterEggInfo({
                title: 'Maskot Kucing MAINku (Duo Sleepy)',
                desc: 'Dua kucing kantor MAINku yang setia menemani tim shift malam di keranjang wol empuknya.',
                icon: '🐱',
                left: 7.5,
                top: 71
              });
            }}
            title="Klik Kucing untuk mengelus"
            className="absolute cursor-pointer rounded-full border border-amber-400/20 hover:border-amber-400 hover:shadow-[0_0_15px_rgba(251,191,36,0.6)] transition-all z-20"
            style={{ left: '3.5%', top: '63%', width: '8.5%', height: '15%' }}
          />

          {/* Coffee Pantry Click Zone */}
          <div 
            onClick={(e) => {
              e.stopPropagation();
              setEasterEggInfo({
                title: 'MAINku Coffee & Snack Corner',
                desc: 'Tempat kopi espresso untuk mengisi ulang stamina AI Agent setelah menyelesaikan ribuan transaksi top up game.',
                icon: '☕',
                left: 68.5,
                top: 21
              });
            }}
            title="Klik Coffee Pantry"
            className="absolute cursor-pointer rounded border border-amber-400/20 hover:border-amber-400 hover:shadow-[0_0_15px_rgba(251,191,36,0.6)] transition-all z-20"
            style={{ left: '64%', top: '12%', width: '10%', height: '17%' }}
          />

          {/* Gaming Lounge Click Zone */}
          <div 
            onClick={(e) => {
              e.stopPropagation();
              setEasterEggInfo({
                title: 'Lounge Santai & Gaming Corner',
                desc: '"Good Game, Good People, Great Results". Sofa empuk untuk tim beristirahat dan uji coba game-game terbaru!',
                icon: '🎮',
                left: 85.5,
                top: 67
              });
            }}
            title="Klik Gaming Lounge"
            className="absolute cursor-pointer rounded-xl border border-amber-400/20 hover:border-amber-400 hover:shadow-[0_0_15px_rgba(251,191,36,0.6)] transition-all z-20"
            style={{ left: '77%', top: '52%', width: '18%', height: '24%' }}
          />

          {/* Easter Egg Popup Card */}
          {easterEggInfo && (
            <div 
              className="absolute z-40 bg-[#121622]/95 border-2 border-amber-500/80 rounded-xl p-3 shadow-2xl backdrop-blur-md max-w-xs animate-in fade-in zoom-in-95 duration-150"
              style={{
                left: `${Math.min(easterEggInfo.left, 70)}%`,
                top: `${Math.max(easterEggInfo.top - 12, 10)}%`,
                transform: 'translate(-50%, -50%)'
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-1.5 pb-1 border-b border-slate-700/80">
                <div className="flex items-center gap-1.5">
                  <span className="text-base">{easterEggInfo.icon}</span>
                  <span className="text-xs font-rpg font-bold text-amber-300">
                    {easterEggInfo.title}
                  </span>
                </div>
                <button 
                  onClick={() => setEasterEggInfo(null)}
                  className="p-1 text-slate-400 hover:text-white rounded"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[11px] text-slate-200 leading-relaxed font-sans">
                {easterEggInfo.desc}
              </p>
            </div>
          )}

          {/* ============================================================ */}
          {/* AGENTS WITH ALIVE MOVEMENT & FLOATING SPEECH BUBBLE CHAT */}
          {/* ============================================================ */}

          {hotspots.map((hotspot) => {
            const agent = getAgentByHotspot(hotspot);
            const isOwner = hotspot.isOwner;
            const status: AgentStatus = isOwner ? 'WORKING' : (agent?.status || 'IDLE');
            const statusStyle = getStatusStyle(status);
            const isPopupOpen = activePopupId === hotspot.id;
            const isHovered = hoveredPopupId === hotspot.id;
            const isWorkingOrChatting = status === 'WORKING' || status === 'CHATTING' || status === 'THINKING';
            const isWorkingOnTask = !isOwner && isWorkingOrChatting;

            // Visibility of speech bubble:
            // In 'TASK_ONLY' mode (default): ONLY pop up when agent is actively working on a task or when hovered. Never standby!
            // In 'ALL' mode: show for all agents.
            // In 'OFF' mode: only show on hover.
            const shouldShowBubble = !isPopupOpen && (
              isHovered ||
              (bubbleMode === 'ALL') ||
              (bubbleMode === 'TASK_ONLY' && isWorkingOnTask)
            );

            // Real-time dialogue speech text
            const dialogueText = isOwner 
              ? hotspot.defaultSpeech 
              : (agent?.activityText || agent?.currentTask || hotspot.defaultSpeech);

            return (
              <div
                key={hotspot.id}
                className="absolute z-30 flex flex-col items-center"
                style={{
                  left: `${hotspot.leftPercent}%`,
                  top: `${hotspot.topPercent}%`,
                  transform: 'translate(-50%, -50%)'
                }}
                onMouseEnter={() => setHoveredPopupId(hotspot.id)}
                onMouseLeave={() => setHoveredPopupId(null)}
              >
                {/* ======================================================= */}
                {/* 1. FLOATING RPG POP-UP BUBBLE CHAT (REAL CHARACTER - NOT EMOTE) */}
                {/* ======================================================= */}
                {shouldShowBubble && (
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      setActivePopupId(hotspot.id);
                    }}
                    className={`absolute bottom-full mb-6 z-40 w-64 sm:w-72 bg-[#0c101b]/95 hover:bg-[#121827] border-2 rounded-2xl p-3 shadow-[0_12px_32px_rgba(0,0,0,0.9)] backdrop-blur-md cursor-pointer transition-all duration-200 hover:scale-105 animate-in zoom-in-95 fade-in slide-in-from-bottom-2 ${
                      isWorkingOrChatting ? 'animate-bubble-float' : ''
                    }`}
                    style={{
                      borderColor: isOwner ? '#f59e0b' : (agent?.ledHex || '#ff1e42'),
                      boxShadow: `0 0 20px ${isOwner ? 'rgba(245,158,11,0.3)' : 'rgba(255,30,66,0.25)'}`
                    }}
                  >
                    {/* Downward Pointer Tail of the Speech Bubble */}
                    <div 
                      className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-[#0c101b] rotate-45 border-r-2 border-b-2 pointer-events-none"
                      style={{ borderColor: isOwner ? '#f59e0b' : (agent?.ledHex || '#ff1e42') }}
                    />

                    {/* Speech Bubble Header: Real Character Face, Name & Status */}
                    <div className="flex items-center gap-2.5 pb-2 mb-2 border-b border-slate-700/60">
                      {/* Character Face Portrait (Layout Character Art - NOT Emote) */}
                      <div className="relative shrink-0">
                        <img 
                          src={hotspot.avatarImage} 
                          alt={hotspot.label}
                          className="w-10 h-10 rounded-xl object-cover border-2 shadow-md bg-slate-900"
                          style={{ borderColor: isOwner ? '#f59e0b' : (agent?.ledHex || '#ff1e42') }}
                          referrerPolicy="no-referrer"
                        />
                        {/* Live status dot on character */}
                        <span className="absolute -bottom-0.5 -right-0.5 flex h-3 w-3">
                          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${statusStyle.ping}`} />
                          <span className={`relative inline-flex rounded-full h-3 w-3 ${statusStyle.dot} border border-slate-900`} />
                        </span>
                      </div>

                      {/* Character Label & Status Pill */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <h4 className="font-rpg font-bold text-xs text-white truncate tracking-wide">
                            {hotspot.label}
                          </h4>
                          
                          {/* Live Status Badge */}
                          <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full border text-[9px] font-pixel ${statusStyle.text} ${statusStyle.bg} ${statusStyle.border}`}>
                            <span>{status}</span>
                          </span>
                        </div>

                        {/* Status Label & Typing Animation */}
                        <div className="flex items-center gap-1.5 text-[9px] font-pixel text-slate-400 mt-0.5">
                          <span className="text-slate-400 truncate">{statusStyle.label}</span>
                          {isWorkingOrChatting && (
                            <div className="flex items-center gap-0.5 px-1 py-0.2 rounded bg-slate-900 border border-slate-700 shrink-0">
                              <span className="w-1 h-1 rounded-full bg-cyan-400 typing-dot-1" />
                              <span className="w-1 h-1 rounded-full bg-cyan-400 typing-dot-2" />
                              <span className="w-1 h-1 rounded-full bg-cyan-400 typing-dot-3" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Speech Bubble Dialogue Body */}
                    <div className="rounded-xl bg-slate-950/70 p-2 border border-slate-800/80 mb-1.5">
                      <p className="text-[11px] font-sans text-slate-100 font-medium leading-tight">
                        "{dialogueText}"
                      </p>
                    </div>

                    {/* Current Task Tag (if available) */}
                    {!isOwner && agent?.currentTask && (
                      <div className="pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                        <span className="text-cyan-400 font-pixel font-bold flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                          TASK:
                        </span>
                        <span className="text-amber-300 font-medium truncate max-w-[155px]">
                          {agent.currentTask}
                        </span>
                      </div>
                    )}

                    {/* Dynamic hint based on active task vs standby */}
                    <div className="text-[8px] font-pixel text-slate-400 text-center mt-1.5 opacity-75">
                      {isWorkingOnTask ? '▶ Sedang proses task • Klik untuk kelola' : '☕ Standby • Klik meja untuk beri task'}
                    </div>
                  </div>
                )}

                {/* ======================================================= */}
                {/* 2. ALIVE AGENT SPRITE & DESK ANIMATION LAYER           */}
                {/* ======================================================= */}
                <div 
                  onClick={(e) => {
                    e.stopPropagation();
                    setActivePopupId(isPopupOpen ? null : hotspot.id);
                  }}
                  className="relative flex flex-col items-center cursor-pointer group"
                >
                  {/* Floor Ambient Ripple / Glow */}
                  <div 
                    className="absolute -bottom-2 w-16 h-7 rounded-full blur-[6px] opacity-60 pointer-events-none transition-all duration-300 group-hover:opacity-100"
                    style={{
                      background: `radial-gradient(ellipse, ${isOwner ? '#f59e0b' : (agent?.ledHex || '#ff1e42')} 0%, transparent 70%)`
                    }}
                  />

                  {/* Character Avatar Representation with Real Character Image (Breathing Bob & Typing Motion) */}
                  <div 
                    className={`relative w-10 h-10 rounded-full bg-[#111726]/90 border-2 flex items-center justify-center shadow-lg transition-transform duration-200 group-hover:scale-110 mb-1 overflow-visible ${
                      isWorkingOrChatting ? 'animate-agent-bob' : ''
                    }`}
                    style={{
                      borderColor: isOwner ? '#f59e0b' : (agent?.ledHex || '#ff1e42'),
                      boxShadow: `0 0 14px ${isOwner ? 'rgba(245,158,11,0.5)' : 'rgba(255,30,66,0.4)'}`
                    }}
                  >
                    {/* Character Face Avatar Portrait (Real Character Art - NOT Emote!) */}
                    <img
                      src={hotspot.avatarImage}
                      alt={hotspot.label}
                      className="w-full h-full rounded-full object-cover select-none pointer-events-none"
                      referrerPolicy="no-referrer"
                    />

                    {/* LIVE STATUS INDICATOR (Top Right of Avatar) */}
                    <div className="absolute -top-1.5 -right-1.5 flex items-center justify-center z-10">
                      {status === 'WORKING' && (
                        <span className="w-4 h-4 rounded-full bg-cyan-500 text-white flex items-center justify-center text-[9px] shadow-sm animate-pulse" title="Mengerjakan Task">
                          ⚡
                        </span>
                      )}
                      {status === 'CHATTING' && (
                        <span className="w-4 h-4 rounded-full bg-purple-500 text-white flex items-center justify-center text-[9px] shadow-sm animate-pulse" title="Chatting / Call">
                          💬
                        </span>
                      )}
                      {status === 'THINKING' && (
                        <span className="w-4 h-4 rounded-full bg-amber-500 text-black flex items-center justify-center text-[9px] shadow-sm animate-spin" title="Berpikir / Analisis">
                          ⚙️
                        </span>
                      )}
                      {status === 'COMPLETED' && (
                        <span className="w-4 h-4 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[9px] shadow-sm animate-bounce" title="Task Selesai">
                          ✓
                        </span>
                      )}
                      {status === 'IDLE' && (
                        <span className="w-4 h-4 rounded-full bg-slate-700 text-slate-300 flex items-center justify-center text-[8px] shadow-sm" title="Standby">
                          ☕
                        </span>
                      )}
                    </div>

                    {/* TYPING HANDS & LAPTOP EFFECT (Bottom of Avatar) */}
                    {isWorkingOrChatting && (
                      <div className="absolute -bottom-1 -left-1 px-1 py-0.2 rounded bg-black/90 border border-cyan-400 text-[8px] animate-agent-typing flex items-center gap-0.5 z-10">
                        <Laptop className="w-2.5 h-2.5 text-cyan-300" />
                        <span className="text-[7px] font-pixel text-cyan-300">TYPING</span>
                      </div>
                    )}
                  </div>

                  {/* 3. AGENT PILL LABEL (MATCHING THE REFERENCE LAYOUT) */}
                  <div
                    className={`relative flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#111622]/95 hover:bg-[#1a2233] border transition-all duration-200 shadow-[0_4px_16px_rgba(0,0,0,0.8)] backdrop-blur-sm ${
                      isPopupOpen 
                        ? 'border-[#ff1e42] ring-2 ring-[#ff1e42]/50 shadow-[0_0_18px_rgba(255,30,66,0.6)] scale-105' 
                        : 'border-slate-600/80 hover:border-amber-400 hover:scale-105'
                    }`}
                  >
                    {/* Character Face Thumbnail */}
                    <img 
                      src={hotspot.avatarImage} 
                      alt="" 
                      className="w-4 h-4 rounded-full object-cover border border-slate-600 shrink-0" 
                      referrerPolicy="no-referrer"
                    />

                    {/* Label Text */}
                    <span className="text-xs font-bold font-rpg tracking-wide text-white whitespace-nowrap">
                      {hotspot.label}
                    </span>

                    {/* Live Status Pulse Dot */}
                    <span className="flex h-2 w-2 relative ml-0.5">
                      <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping ${statusStyle.ping}`} />
                      <span className={`relative inline-flex rounded-full h-2 w-2 ${statusStyle.dot}`} />
                    </span>
                  </div>
                </div>

                {/* ======================================================= */}
                {/* 4. DETAILED EXPANDED MANAGEMENT CARD (WHEN CLICKED)   */}
                {/* ======================================================= */}
                {isPopupOpen && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="absolute z-50 bottom-full mb-3 w-72 sm:w-80 bg-[#121724]/98 border-2 rounded-2xl p-4 shadow-[0_16px_36px_rgba(0,0,0,0.9)] backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
                    style={{
                      borderColor: isOwner ? '#f59e0b' : (agent?.ledHex || '#ff1e42'),
                      boxShadow: `0 0 25px ${isOwner ? 'rgba(245,158,11,0.3)' : 'rgba(255,30,66,0.25)'}`
                    }}
                  >
                    {/* Pointer Arrow down to the label */}
                    <div 
                      className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-[#121724] rotate-45 border-r-2 border-b-2"
                      style={{ borderColor: isOwner ? '#f59e0b' : (agent?.ledHex || '#ff1e42') }}
                    />

                    {/* Pop-up Header */}
                    <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-700/80 mb-2.5">
                      <div className="flex items-center gap-2.5">
                        <div 
                          className="w-11 h-11 rounded-xl bg-slate-900 border-2 overflow-hidden shadow-md shrink-0"
                          style={{ borderColor: isOwner ? '#f59e0b' : (agent?.ledHex || '#3b82f6') }}
                        >
                          <img 
                            src={hotspot.avatarImage} 
                            alt={hotspot.label}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="text-sm font-bold font-rpg text-white tracking-wide">
                              {isOwner ? 'Anggi Pras' : agent?.name}
                            </h4>
                          </div>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-[10px] font-pixel text-amber-300">
                              {hotspot.label}
                            </span>
                            <span className="text-slate-500">•</span>
                            <span className={`text-[10px] font-pixel font-bold px-1.5 py-0.2 rounded border ${statusStyle.text} ${statusStyle.bg} ${statusStyle.border}`}>
                              {status}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Close button */}
                      <button
                        onClick={() => setActivePopupId(null)}
                        className="p-1 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Speech / Live Activity Bubble */}
                    <div className="p-2.5 rounded-xl bg-slate-950/85 border border-slate-800 mb-3 relative">
                      <div className="flex items-center gap-1 text-[9px] font-pixel text-slate-400 mb-1">
                        <MessageSquare className="w-3 h-3 text-cyan-400" />
                        <span>AKTIVITAS SAAT INI (REAL-TIME SPEECH & TASK):</span>
                      </div>
                      <p className="text-xs text-slate-100 font-medium leading-snug">
                        "{dialogueText}"
                      </p>
                      {!isOwner && agent?.currentTask && (
                        <div className="mt-1.5 pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                          <span className="text-slate-400 font-pixel">Current Task:</span>
                          <span className="text-cyan-300 font-medium truncate max-w-[150px]">{agent.currentTask}</span>
                        </div>
                      )}
                    </div>

                    {/* Status Changer Buttons (Only for Agents) */}
                    {!isOwner && agent && (
                      <div className="mb-3">
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[9px] font-pixel text-slate-400">
                            STATUS AGENT: <strong className={statusStyle.text}>{agent.status}</strong>
                          </span>
                          <span className="text-[9px] font-pixel text-emerald-400">
                            {agent.completedTasksToday} done
                          </span>
                        </div>
                        <div className="grid grid-cols-4 gap-1">
                          <button
                            onClick={() => onUpdateAgentStatus(agent.id, 'WORKING')}
                            className={`py-1.5 px-1 rounded-lg text-[9px] font-pixel transition-all border text-center cursor-pointer ${
                              agent.status === 'WORKING'
                                ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold shadow-[0_0_8px_rgba(6,182,212,0.6)]'
                                : 'bg-slate-900/90 text-cyan-300 border-slate-800 hover:border-cyan-500/50'
                            }`}
                            title="Mengerjakan task teknis / analisis / render"
                          >
                            ⚡ WORK
                          </button>
                          <button
                            onClick={() => onUpdateAgentStatus(agent.id, 'CHATTING')}
                            className={`py-1.5 px-1 rounded-lg text-[9px] font-pixel transition-all border text-center cursor-pointer ${
                              agent.status === 'CHATTING'
                                ? 'bg-purple-500 text-white border-purple-400 font-bold shadow-[0_0_8px_rgba(168,85,247,0.6)]'
                                : 'bg-slate-900/90 text-purple-300 border-slate-800 hover:border-purple-500/50'
                            }`}
                            title="Chat WhatsApp dengan pelanggan / CS"
                          >
                            💬 CHAT
                          </button>
                          <button
                            onClick={() => onUpdateAgentStatus(agent.id, 'IDLE')}
                            className={`py-1.5 px-1 rounded-lg text-[9px] font-pixel transition-all border text-center cursor-pointer ${
                              agent.status === 'IDLE'
                                ? 'bg-slate-600 text-white border-slate-500 font-bold'
                                : 'bg-slate-900/90 text-slate-400 border-slate-800 hover:border-slate-700'
                            }`}
                            title="Standby di meja kerja"
                          >
                            ☕ IDLE
                          </button>
                          <button
                            onClick={() => onUpdateAgentStatus(agent.id, 'COMPLETED')}
                            className={`py-1.5 px-1 rounded-lg text-[9px] font-pixel transition-all border text-center cursor-pointer ${
                              agent.status === 'COMPLETED'
                                ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold shadow-[0_0_8px_rgba(16,185,129,0.6)]'
                                : 'bg-slate-900/90 text-emerald-300 border-slate-800 hover:border-emerald-500/50'
                            }`}
                            title="Task selesai"
                          >
                            ✓ DONE
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Pop-up Bottom Action Buttons */}
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                      {!isOwner && agent ? (
                        <>
                          <button
                            onClick={() => {
                              onAssignQuickTask(agent.id);
                              setActivePopupId(null);
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-rpg text-xs font-bold shadow-md cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                            <span>Beri Task</span>
                          </button>
                          
                          <button
                            onClick={() => {
                              setFullModalAgent(agent);
                              setActivePopupId(null);
                            }}
                            className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-rpg text-xs font-semibold flex items-center gap-1 cursor-pointer"
                            title="Buka detail lengkap"
                          >
                            <Maximize2 className="w-3.5 h-3.5" />
                            <span>Detail</span>
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => {
                            setShowOwnerModal(true);
                            setActivePopupId(null);
                          }}
                          className="w-full py-1.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-rpg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <ShieldCheck className="w-4 h-4" />
                          <span>Buka Profil Owner</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Quick instructions floating badge at bottom of photo */}
          <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-20 px-3 py-1 rounded-full bg-black/75 border border-slate-700 text-[10px] font-rpg text-slate-300 pointer-events-none flex items-center gap-2 shadow-lg backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>MAINku Animated Virtual Office • Bubble Chat melayang real-time di atas setiap agent yang sedang bekerja</span>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* FULL INSPECTION MODAL (When clicking "Detail" inside pop-up) */}
      {/* ============================================================ */}
      {fullModalAgent && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div 
            id="agent-detail-modal"
            className="w-full max-w-lg bg-[#141822] border-2 rounded-2xl p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200"
            style={{ borderColor: fullModalAgent.ledHex }}
          >
            {/* Close button */}
            <button
              onClick={() => setFullModalAgent(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-4 mb-4">
              <div 
                className="w-14 h-14 rounded-2xl overflow-hidden border-2 bg-slate-900 shadow-lg shrink-0"
                style={{ borderColor: fullModalAgent.ledHex }}
              >
                <img 
                  src={fullModalAgent.avatarImage || getAgentAvatar(fullModalAgent.id)}
                  alt={fullModalAgent.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-bold font-rpg text-white">
                    {fullModalAgent.name}
                  </h3>
                  <span className="text-xs px-2 py-0.5 rounded font-pixel bg-slate-800 text-slate-300">
                    {fullModalAgent.role}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  ID Workstation: #{fullModalAgent.id.toUpperCase()}
                </p>
              </div>
            </div>

            {/* Current Activity Box */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 mb-4">
              <span className="text-[10px] font-pixel text-slate-400 block mb-1">
                AKTIVITAS SAAT INI (SPEECH & STATUS)
              </span>
              <p className="text-sm font-semibold text-slate-100">
                "{fullModalAgent.activityText}"
              </p>
              <p className="text-xs text-slate-400 mt-2">
                <span className="text-slate-500 font-pixel">Current Task:</span> {fullModalAgent.currentTask || 'Standby di meja kerja'}
              </p>
            </div>

            {/* Quick Change Status */}
            <div className="mb-5">
              <label className="text-xs font-pixel text-slate-300 block mb-2">
                UBAH STATUS OPERASIONAL AGENT (LIVE STATUS CHANGER):
              </label>
              <div className="grid grid-cols-4 gap-2">
                <button
                  onClick={() => {
                    onUpdateAgentStatus(fullModalAgent.id, 'WORKING');
                    setFullModalAgent({ ...fullModalAgent, status: 'WORKING' });
                  }}
                  className={`py-2.5 px-2 rounded-xl text-xs font-pixel transition-all border text-center cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    fullModalAgent.status === 'WORKING'
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                      : 'bg-slate-900/90 text-cyan-300 border-slate-800 hover:border-cyan-500/50'
                  }`}
                >
                  <span className="text-sm">⚡</span>
                  <span>WORKING</span>
                  <span className="text-[9px] opacity-75 font-sans">Pengerjaan Task</span>
                </button>

                <button
                  onClick={() => {
                    onUpdateAgentStatus(fullModalAgent.id, 'CHATTING');
                    setFullModalAgent({ ...fullModalAgent, status: 'CHATTING' });
                  }}
                  className={`py-2.5 px-2 rounded-xl text-xs font-pixel transition-all border text-center cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    fullModalAgent.status === 'CHATTING'
                      ? 'bg-purple-500 text-white border-purple-400 font-bold shadow-[0_0_12px_rgba(168,85,247,0.6)]'
                      : 'bg-slate-900/90 text-purple-300 border-slate-800 hover:border-purple-500/50'
                  }`}
                >
                  <span className="text-sm">💬</span>
                  <span>CHATTING</span>
                  <span className="text-[9px] opacity-75 font-sans">WhatsApp / CS</span>
                </button>

                <button
                  onClick={() => {
                    onUpdateAgentStatus(fullModalAgent.id, 'IDLE');
                    setFullModalAgent({ ...fullModalAgent, status: 'IDLE' });
                  }}
                  className={`py-2.5 px-2 rounded-xl text-xs font-pixel transition-all border text-center cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    fullModalAgent.status === 'IDLE'
                      ? 'bg-slate-600 text-white border-slate-500 font-bold'
                      : 'bg-slate-900/90 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span className="text-sm">☕</span>
                  <span>IDLE</span>
                  <span className="text-[9px] opacity-75 font-sans">Standby Meja</span>
                </button>

                <button
                  onClick={() => {
                    onUpdateAgentStatus(fullModalAgent.id, 'COMPLETED');
                    setFullModalAgent({ ...fullModalAgent, status: 'COMPLETED' });
                  }}
                  className={`py-2.5 px-2 rounded-xl text-xs font-pixel transition-all border text-center cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    fullModalAgent.status === 'COMPLETED'
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold shadow-[0_0_12px_rgba(16,185,129,0.6)]'
                      : 'bg-slate-900/90 text-emerald-300 border-slate-800 hover:border-emerald-500/50'
                  }`}
                >
                  <span className="text-sm">✓</span>
                  <span>COMPLETED</span>
                  <span className="text-[9px] opacity-75 font-sans">Task Selesai</span>
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => {
                  onAssignQuickTask(fullModalAgent.id);
                  setFullModalAgent(null);
                }}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-rpg text-xs font-bold shadow-lg cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Beri Task Baru ke {fullModalAgent.name}</span>
              </button>
              
              <button
                onClick={() => setFullModalAgent(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-rpg text-xs font-semibold cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* OWNER MODAL PROFILE */}
      {/* ============================================================ */}
      {showOwnerModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#161c27] border-2 border-amber-500/80 rounded-2xl p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setShowOwnerModal(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl overflow-hidden shadow-lg border-2 border-amber-300 shrink-0 bg-slate-900">
                <img 
                  src={AGENT_AVATARS.owner} 
                  alt="Anggi Pras" 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <h3 className="text-lg font-bold font-rpg text-white flex items-center gap-1.5">
                  <span>Anggi Pras</span>
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                </h3>
                <p className="text-xs font-pixel text-amber-300">
                  OWNER & FOUNDER • MAINku.com
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 mb-4 text-xs space-y-2">
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500 font-pixel">STATUS:</span>
                <span className="text-emerald-400 font-pixel font-bold">ONLINE (COMMAND DECK ACTIVE)</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500 font-pixel">AI AGENTS SUPERVISED:</span>
                <span className="font-pixel text-slate-200">6 Agents</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span className="text-slate-500 font-pixel">BUSINESS DOMAIN:</span>
                <span className="font-pixel text-cyan-300">Game Top Up (MLBB, FF, Genshin, Valo)</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Anda memegang kendali tertinggi atas alur kerja otomatisasi AI Office. AI Manager akan menerjemahkan arahan strategis Anda menjadi task operasional untuk tim Sales, Creative, dan CS.
            </p>

            <button
              onClick={() => setShowOwnerModal(false)}
              className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-rpg font-bold text-xs shadow-lg cursor-pointer"
            >
              Kembali ke Virtual Office
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
