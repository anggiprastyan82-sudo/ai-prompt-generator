import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Sparkles, 
  PhoneCall, 
  Filter, 
  ShieldAlert, 
  CheckCircle,
  TrendingUp,
  MessageCircle
} from 'lucide-react';
import { Customer } from '../../types';

interface CustomersViewProps {
  customers: Customer[];
  onTriggerFollowUp: (customer: Customer) => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  customers,
  onTriggerFollowUp
}) => {
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch = 
      c.nameOfMember.toLowerCase().includes(search.toLowerCase()) ||
      c.contact.includes(search) ||
      c.tierCompetitor.toLowerCase().includes(search.toLowerCase());
    const matchesPriority = priorityFilter === 'ALL' || c.salesPriority === priorityFilter;
    const matchesStatus = statusFilter === 'ALL' || c.customerStatus === statusFilter;
    return matchesSearch && matchesPriority && matchesStatus;
  });

  const getPriorityStyle = (priority: Customer['salesPriority']) => {
    switch (priority) {
      case 'URGENT':
        return 'bg-red-500/20 text-[#ff1e42] border-[#ff1e42]/50 font-bold';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'MEDIUM':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case 'LOW':
        return 'bg-slate-700/30 text-slate-400 border-slate-700';
    }
  };

  const getCustomerStatusStyle = (status: Customer['customerStatus']) => {
    switch (status) {
      case 'Active':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'Prospect':
        return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30';
      case 'Churn Risk':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-semibold';
      case 'Dormant':
        return 'bg-slate-700/20 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold font-rpg text-white tracking-wide">
              DATABASE CUSTOMER & VIP LEADS
            </h2>
            <span className="text-xs font-pixel px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              SHEET 1: CUSTOMER
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Data calon member sultan & pemain top up game dari competitor yang dianalisis oleh AI Manager.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-center gap-2">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Total: <strong className="text-white font-pixel">{customers.length}</strong> Leads</span>
          </div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Cari nama member, kontak, tier..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#ff1e42]"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300"
          >
            <option value="ALL">Semua Sales Priority</option>
            <option value="URGENT">URGENT</option>
            <option value="HIGH">HIGH</option>
            <option value="MEDIUM">MEDIUM</option>
            <option value="LOW">LOW</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300"
          >
            <option value="ALL">Semua Customer Status</option>
            <option value="Active">Active</option>
            <option value="Prospect">Prospect</option>
            <option value="Churn Risk">Churn Risk</option>
          </select>
        </div>
      </div>

      {/* Customers Table (Matching Sheet 1: CUSTOMER columns exactly) */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#0b1122] text-slate-400 font-pixel text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">NAME OF MEMBER</th>
                <th className="py-3.5 px-4">CONTACT</th>
                <th className="py-3.5 px-4">TIER DI COMPETITOR</th>
                <th className="py-3.5 px-4">CUSTOMER STATUS</th>
                <th className="py-3.5 px-4">LAST CONTACT</th>
                <th className="py-3.5 px-4">SALES PRIORITY</th>
                <th className="py-3.5 px-4 max-w-sm">AI RECOMMENDATION</th>
                <th className="py-3.5 px-4">FOLLOW UP STATUS</th>
                <th className="py-3.5 px-4 text-right">AKSI AI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500 font-pixel">
                    Tidak ada member yang cocok dengan filter
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => (
                  <tr key={cust.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-white whitespace-nowrap">
                      {cust.nameOfMember}
                      {cust.favoriteGame && (
                        <span className="block text-[10px] font-normal text-slate-400 font-pixel">
                          🎮 {cust.favoriteGame}
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-pixel text-slate-300 whitespace-nowrap">
                      {cust.contact}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded bg-amber-500/15 border border-amber-500/30 text-amber-300 font-pixel text-[10px]">
                        {cust.tierCompetitor}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-pixel ${getCustomerStatusStyle(cust.customerStatus)}`}>
                        {cust.customerStatus}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap text-[11px]">
                      {cust.lastContact}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-pixel ${getPriorityStyle(cust.salesPriority)}`}>
                        {cust.salesPriority}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-200 font-medium leading-relaxed max-w-xs">
                      <div className="flex items-start gap-1.5 p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                        <Sparkles className="w-3.5 h-3.5 text-[#ff1e42] shrink-0 mt-0.5" />
                        <span className="text-[11px]">{cust.aiRecommendation}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-pixel">
                        {cust.followUpStatus}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => onTriggerFollowUp(cust)}
                        className="px-2.5 py-1.5 rounded-lg bg-[#ff1e42]/20 hover:bg-[#ff1e42] text-[#ff1e42] hover:text-white border border-[#ff1e42]/50 text-[10px] font-rpg font-bold transition-all flex items-center gap-1 ml-auto"
                        title="Tugaskan Sales Membership untuk follow-up"
                      >
                        <MessageCircle className="w-3 h-3" />
                        <span>Follow Up AI</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
