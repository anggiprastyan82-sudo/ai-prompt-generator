import React from 'react';
import { 
  Bot, 
  Gamepad2, 
  Zap, 
  Users, 
  CheckSquare, 
  TrendingUp, 
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Flame
} from 'lucide-react';
import { AgentInfo, Task, Customer, NavigationTab } from '../../types';
import { MainkuLogo } from '../MainkuLogo';

interface HomeOverviewProps {
  agents: AgentInfo[];
  tasks: Task[];
  customers: Customer[];
  onNavigate: (tab: NavigationTab) => void;
  onSimulateWorkflow: () => void;
  isSimulating: boolean;
}

export const HomeOverview: React.FC<HomeOverviewProps> = ({
  agents,
  tasks,
  customers,
  onNavigate,
  onSimulateWorkflow,
  isSimulating
}) => {
  const pendingTasks = tasks.filter(t => t.status === 'IN_PROGRESS' || t.status === 'PENDING').length;
  const urgentLeads = customers.filter(c => c.salesPriority === 'URGENT').length;
  const workingAgents = agents.filter(a => a.status === 'WORKING' || a.status === 'CHATTING').length;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Hero Welcome Card with Mascot */}
      <div className="relative rounded-3xl p-6 md:p-8 bg-gradient-to-r from-slate-900 via-[#10172e] to-[#1c1228] border-2 border-slate-800 shadow-2xl overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#ff1e42]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#ff1e42]/20 border border-[#ff1e42]/50 text-[#ff1e42] font-pixel text-xs flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" />
                <span>TOP UP GAME AUTOMATION</span>
              </span>
              <span className="text-xs text-slate-400 font-pixel">
                MAINku.com Virtual HQ
              </span>
            </div>

            <h1 className="text-2xl md:text-4xl font-extrabold font-rpg text-white tracking-wide leading-tight">
              Selamat Datang di <span className="text-[#ff1e42] drop-shadow-[0_0_12px_rgba(255,30,66,0.6)]">MAINku AI Office</span>
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed">
              Virtual office berbasis AI Agent yang bekerja 24/7 untuk mengelola customer sultan, otomatisasi penawaran promo game (Mobile Legends, Free Fire, Genshin, Valorant), dan delegasi task bisnis top up Anda.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onNavigate('office')}
                className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#ff1e42] to-red-600 hover:from-red-600 hover:to-[#ff1e42] text-white font-rpg font-bold text-xs shadow-[0_0_20px_rgba(255,30,66,0.4)] transition-all hover:scale-105 active:scale-95"
              >
                <Bot className="w-4 h-4" />
                <span>Buka Virtual Office 2D</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onSimulateWorkflow}
                disabled={isSimulating}
                className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-rpg font-semibold text-xs transition-all"
              >
                <Zap className={`w-4 h-4 ${isSimulating ? 'text-[#ff1e42] animate-spin' : 'text-amber-400'}`} />
                <span>{isSimulating ? 'Memproses Workflow AI...' : 'Jalankan Simulasi Workflow'}</span>
              </button>
            </div>
          </div>

          {/* Right Mascot Feature */}
          <div className="shrink-0 p-5 rounded-3xl bg-slate-950/70 border border-slate-800/90 shadow-xl flex flex-col items-center text-center">
            <MainkuLogo size="large" />
            <div className="mt-3">
              <div className="font-rpg font-bold text-white text-sm">
                MAINku Cat Mascot
              </div>
              <p className="text-[11px] text-slate-400 font-pixel mt-0.5">
                Kardus Kepala "M"
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Quick Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1 */}
        <div 
          onClick={() => onNavigate('office')}
          className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-pixel">AI AGENT AKTIF</span>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Bot className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-bold font-rpg text-white">
            {workingAgents} <span className="text-sm font-pixel text-slate-500">/ 6 Agent</span>
          </div>
          <p className="text-xs text-slate-400 mt-2 flex items-center justify-between">
            <span>Sedang working & chatting</span>
            <span className="text-blue-400 font-pixel group-hover:underline">Lihat Office →</span>
          </p>
        </div>

        {/* Metric 2 */}
        <div 
          onClick={() => onNavigate('tasks')}
          className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-[#ff1e42]/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-pixel">TASK DALAM PENGERJAAN</span>
            <div className="w-8 h-8 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-[#ff1e42]">
              <CheckSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-bold font-rpg text-white">
            {pendingTasks} <span className="text-sm font-pixel text-[#ff1e42]">Active Tasks</span>
          </div>
          <p className="text-xs text-slate-400 mt-2 flex items-center justify-between">
            <span>Didelegasikan ke tim</span>
            <span className="text-[#ff1e42] font-pixel group-hover:underline">Buka Tasks →</span>
          </p>
        </div>

        {/* Metric 3 */}
        <div 
          onClick={() => onNavigate('customers')}
          className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-pixel">LEADS SULTAN URGENT</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-bold font-rpg text-amber-400">
            {urgentLeads} <span className="text-sm font-pixel text-slate-400">Pemain Whale</span>
          </div>
          <p className="text-xs text-slate-400 mt-2 flex items-center justify-between">
            <span>Siap di-pitching VIP</span>
            <span className="text-amber-400 font-pixel group-hover:underline">Cek Customer →</span>
          </p>
        </div>
      </div>

      {/* Agents Quick Workstation Roster */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-rpg font-bold text-white text-base">
              Daftar 6 AI Agent Virtual Office
            </h3>
            <p className="text-xs text-slate-400">
              Setiap karakter memegang divisi khusus dalam ekosistem MAINku.com.
            </p>
          </div>

          <button
            onClick={() => onNavigate('office')}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-pixel text-slate-200 border border-slate-700 flex items-center gap-1.5"
          >
            <span>Buka 2D Office View</span>
            <ArrowRight className="w-3 h-3 text-[#ff1e42]" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {agents.map((agent) => (
            <div
              key={agent.id}
              onClick={() => onNavigate('office')}
              className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 text-center cursor-pointer transition-transform hover:-translate-y-1 group"
            >
              <div 
                className="w-12 h-12 mx-auto mb-2 rounded-xl overflow-hidden border-2 bg-slate-900 group-hover:scale-110 transition-transform shadow-md"
                style={{ borderColor: agent.ledHex }}
              >
                {agent.avatarImage ? (
                  <img 
                    src={agent.avatarImage} 
                    alt={agent.name} 
                    className="w-full h-full object-cover" 
                    referrerPolicy="no-referrer" 
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-2xl">{agent.icon}</div>
                )}
              </div>
              <h4 className="font-rpg font-bold text-xs text-white group-hover:text-[#ff1e42] truncate">
                {agent.name}
              </h4>
              <p className="text-[10px] text-slate-500 font-pixel mt-0.5">
                {agent.role}
              </p>
              <div className="mt-2 inline-block px-2 py-0.5 rounded-full text-[9px] font-pixel bg-slate-900 text-slate-400 border border-slate-800">
                {agent.status}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
