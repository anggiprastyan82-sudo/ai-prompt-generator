import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Award, 
  Clock, 
  CheckCircle2, 
  Star 
} from 'lucide-react';
import { PerformanceReport } from '../../types';

interface ReportsViewProps {
  reports: PerformanceReport[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ reports }) => {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold font-rpg text-white tracking-wide">
              LAPORAN PERFORMA AI AGENT
            </h2>
            <span className="text-xs font-pixel px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              SHEET 4: REPORTS
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Metrik efisiensi kerja, conversion rate member baru, dan rating kepuasan top up MAINku.com.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <Award className="w-5 h-5 text-amber-400" />
            <div>
              <div className="text-[10px] text-slate-400 font-pixel">TOP AGENT BULAN INI</div>
              <div className="text-xs font-bold text-white font-rpg">🎧 Customer Service (99% Conv)</div>
            </div>
          </div>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 font-pixel">TOTAL TASK SELESAI</span>
          <div className="text-2xl font-bold font-rpg text-white mt-1">
            242 <span className="text-xs font-pixel text-emerald-400 font-normal">+14% hari ini</span>
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 font-pixel">LEADS TERPROSES</span>
          <div className="text-2xl font-bold font-rpg text-white mt-1">
            2,664 <span className="text-xs font-pixel text-[#ff1e42] font-normal">Sultan Gamers</span>
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 font-pixel">RATA-RATA RESPON CS</span>
          <div className="text-2xl font-bold font-rpg text-emerald-400 mt-1">
            45 Detik <span className="text-xs font-pixel text-slate-400 font-normal">Super Cepat</span>
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 font-pixel">SKOR KEPUASAN (CSAT)</span>
          <div className="text-2xl font-bold font-rpg text-amber-400 mt-1 flex items-center gap-1">
            <span>97.2%</span>
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
          </div>
        </div>
      </div>

      {/* Reports Table (Matching Sheet 4 Columns) */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#0b1122] text-slate-400 font-pixel text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">AGENT</th>
                <th className="py-3.5 px-4">TASKS COMPLETED</th>
                <th className="py-3.5 px-4">LEADS / VOLUME</th>
                <th className="py-3.5 px-4">CONVERSION RATE</th>
                <th className="py-3.5 px-4">AVG RESPONSE TIME</th>
                <th className="py-3.5 px-4">SATISFACTION SCORE</th>
                <th className="py-3.5 px-4 text-right">STATUS EFISIENSI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {reports.map((rep) => (
                <tr key={rep.agentId} className="hover:bg-slate-800/50 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-white font-rpg text-sm whitespace-nowrap">
                    {rep.agentName}
                  </td>
                  <td className="py-3.5 px-4 font-pixel text-slate-200">
                    {rep.tasksCompleted} Task
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 font-pixel">
                    {rep.leadsProcessed}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2.5 py-0.5 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/30 font-pixel text-[10px]">
                      {rep.conversionRate}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-pixel text-slate-300">
                    {rep.avgResponseTime}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                        <div 
                          className="h-full bg-amber-400"
                          style={{ width: `${rep.satisfactionScore}%` }}
                        />
                      </div>
                      <span className="font-pixel text-amber-400 font-bold">{rep.satisfactionScore}%</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-pixel">
                      OPTIMAL
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
