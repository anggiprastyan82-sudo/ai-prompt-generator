import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  CheckCircle, 
  ExternalLink, 
  Copy, 
  Sparkles, 
  ShieldCheck, 
  Layers 
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [copiedSheet, setCopiedSheet] = useState<string | null>(null);

  const sheets = [
    {
      name: 'Sheet 1: CUSTOMER',
      columns: [
        'Name of member',
        'Contact',
        'Tier di competitor',
        'Customer Status',
        'Last Contact',
        'Sales Priority',
        'AI Recommendation',
        'Follow Up Status'
      ],
      desc: 'Database prospek dan pelanggan setia top up game MAINku.com'
    },
    {
      name: 'Sheet 2: TASK',
      columns: [
        'TASK ID',
        'AGENT',
        'TASK',
        'PRIORITY',
        'STATUS',
        'CREATED AT',
        'RESULT'
      ],
      desc: 'Daftar penugasan dari Owner atau AI Manager ke agent kerja'
    },
    {
      name: 'Sheet 3: AGENT ACTIVITY',
      columns: [
        'TIME',
        'AGENT',
        'ACTIVITY',
        'CUSTOMER',
        'STATUS'
      ],
      desc: 'Log histori aktivitas yang ditampilkan pada panel kanan dashboard'
    },
    {
      name: 'Sheet 4: REPORTS',
      columns: [
        'AGENT',
        'TASKS COMPLETED',
        'LEADS PROCESSED',
        'CONVERSION RATE',
        'AVG RESPONSE TIME',
        'SATISFACTION SCORE'
      ],
      desc: 'Laporan metrik efisiensi dan performa bisnis mingguan/bulanan'
    }
  ];

  const handleCopyColumns = (name: string, cols: string[]) => {
    navigator.clipboard.writeText(cols.join('\t'));
    setCopiedSheet(name);
    setTimeout(() => setCopiedSheet(null), 2000);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold font-rpg text-white tracking-wide">
            PENGATURAN & STRUKTUR GOOGLE SHEETS
          </h2>
          <span className="text-xs font-pixel px-2 py-0.5 rounded bg-[#ff1e42]/20 text-[#ff1e42] border border-[#ff1e42]/40">
            PHASE 4 READINESS
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Panduan struktur database Google Sheets untuk menghubungkan live spreadsheet dengan MAINku AI Office.
        </p>
      </div>

      {/* Info Card: Google Sheets Architecture */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900/90 to-slate-950/90 border border-slate-800">
        <div className="flex items-center gap-3 mb-3">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-rpg font-bold text-white text-base">
              Rancangan 4 Tab Google Sheets Anda
            </h3>
            <p className="text-xs text-slate-400">
              Format header kolom di bawah sudah 100% cocok dengan aplikasi ini. Anda cukup membuat 1 file Google Spreadsheet dengan 4 sheet berikut:
            </p>
          </div>
        </div>

        {/* 4 Sheets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {sheets.map((s) => (
            <div 
              key={s.name}
              className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <h4 className="font-rpg font-bold text-sm text-[#ff1e42]">
                    {s.name}
                  </h4>
                  <button
                    onClick={() => handleCopyColumns(s.name, s.columns)}
                    className="flex items-center gap-1 text-[10px] font-pixel text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 border border-slate-700 transition-colors"
                    title="Copy baris kolom untuk dipaste ke Google Sheets"
                  >
                    {copiedSheet === s.name ? (
                      <>
                        <CheckCircle className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Tersalin!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Kolom</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-xs text-slate-400 mb-3">
                  {s.desc}
                </p>

                <div className="space-y-1">
                  <span className="text-[10px] font-pixel text-slate-500">KOLOM:</span>
                  <div className="flex flex-wrap gap-1">
                    {s.columns.map((col) => (
                      <span 
                        key={col}
                        className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-pixel text-[10px] border border-slate-700/80"
                      >
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Workflow Reference */}
      <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 text-xs">
        <h4 className="font-rpg font-bold text-white text-sm mb-2 flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#ff1e42]" />
          <span>Alur Kerja AI (Workflow Concept)</span>
        </h4>
        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 font-pixel text-slate-300 space-y-1.5 text-[11px] leading-relaxed">
          <div className="text-slate-400">1. OWNER memberi arahan: "Cari customer potensial untuk membership."</div>
          <div className="text-blue-400">↓ 2. AI MANAGER membaca Sheet CUSTOMER & menganalisis leads sultan</div>
          <div className="text-amber-400">↓ 3. AI MANAGER membuat task di Sheet TASK untuk Sales Membership</div>
          <div className="text-cyan-400">↓ 4. SALES MEMBERSHIP mengambil task, status berubah jadi CHATTING/WORKING</div>
          <div className="text-purple-400">↓ 5. Log otomatis tersimpan di Sheet AGENT ACTIVITY & ditampilkan di panel kanan</div>
          <div className="text-emerald-400">↓ 6. Virtual office terupdate secara real-time</div>
        </div>
      </div>
    </div>
  );
};
