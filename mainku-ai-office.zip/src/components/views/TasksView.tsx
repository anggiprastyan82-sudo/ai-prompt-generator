import React, { useState } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  X, 
  Send,
  Zap,
  MessageSquare,
  Coffee
} from 'lucide-react';
import { Task, PriorityLevel, AgentId, AgentStatus } from '../../types';

interface TasksViewProps {
  tasks: Task[];
  onAddTask: (newTask: Omit<Task, 'taskId' | 'createdAt'>) => void;
  onUpdateTaskStatus: (taskId: string, status: Task['status'], directAgentStatus?: AgentStatus) => void;
}

export const TasksView: React.FC<TasksViewProps> = ({
  tasks,
  onAddTask,
  onUpdateTaskStatus
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAgent, setFilterAgent] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New task form state
  const [agentName, setAgentName] = useState('Sales Membership');
  const [taskTitle, setTaskTitle] = useState('');
  const [priority, setPriority] = useState<PriorityLevel>('HIGH');
  const [agentWorkingStatus, setAgentWorkingStatus] = useState<'WORKING' | 'CHATTING'>('WORKING');

  const filteredTasks = tasks.filter((t) => {
    const matchesSearch = 
      t.task.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.taskId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.agent.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAgent = filterAgent === 'ALL' || t.agent.toLowerCase().includes(filterAgent.toLowerCase());
    const matchesStatus = filterStatus === 'ALL' || t.status === filterStatus || t.agentWorkingStatus === filterStatus;
    return matchesSearch && matchesAgent && matchesStatus;
  });

  const handleAgentSelectChange = (selectedName: string) => {
    setAgentName(selectedName);
    // Smart default suggestion
    if (selectedName.includes('Customer') || selectedName.includes('Membership')) {
      setAgentWorkingStatus('CHATTING');
    } else {
      setAgentWorkingStatus('WORKING');
    }
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    let agentId: AgentId = 'sales_membership';
    if (agentName.includes('Manager')) agentId = 'ai_manager';
    else if (agentName.includes('Promo')) agentId = 'sales_promo';
    else if (agentName.includes('Creative')) agentId = 'creative_agent';
    else if (agentName.includes('Customer')) agentId = 'customer_service';
    else if (agentName.includes('Support')) agentId = 'support_hub';

    onAddTask({
      agent: agentName,
      agentId,
      task: taskTitle,
      priority,
      status: 'IN_PROGRESS',
      agentWorkingStatus: agentWorkingStatus,
      result: `Sedang diproses [${agentWorkingStatus}] oleh ${agentName}`
    });

    setTaskTitle('');
    setIsModalOpen(false);
  };

  const getPriorityBadge = (p: PriorityLevel) => {
    switch (p) {
      case 'URGENT':
        return 'bg-red-500/20 text-[#ff1e42] border-[#ff1e42]/50 font-bold';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'MEDIUM':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case 'LOW':
        return 'bg-slate-700/30 text-slate-400 border-slate-700';
    }
  };

  const getStatusBadge = (s: Task['status']) => {
    switch (s) {
      case 'COMPLETED':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      case 'IN_PROGRESS':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 animate-pulse';
      case 'PENDING':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'CANCELLED':
        return 'bg-slate-700/20 text-slate-500 border-slate-700';
    }
  };

  const getAgentStatusBadge = (st?: AgentStatus) => {
    switch (st) {
      case 'WORKING':
        return {
          pill: 'bg-cyan-950/80 text-cyan-300 border-cyan-500/60 shadow-[0_0_8px_rgba(6,182,212,0.3)]',
          dot: 'bg-cyan-400 animate-pulse',
          icon: '⚡',
          label: 'WORKING'
        };
      case 'CHATTING':
        return {
          pill: 'bg-purple-950/80 text-purple-300 border-purple-500/60 shadow-[0_0_8px_rgba(168,85,247,0.3)]',
          dot: 'bg-purple-400 animate-pulse',
          icon: '💬',
          label: 'CHATTING'
        };
      case 'COMPLETED':
        return {
          pill: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/60',
          dot: 'bg-emerald-400',
          icon: '✓',
          label: 'COMPLETED'
        };
      case 'IDLE':
      default:
        return {
          pill: 'bg-slate-900 text-slate-400 border-slate-700',
          dot: 'bg-slate-400',
          icon: '☕',
          label: 'IDLE'
        };
    }
  };

  // Status counts
  const workingCount = tasks.filter(t => t.status === 'IN_PROGRESS' && t.agentWorkingStatus === 'WORKING').length;
  const chattingCount = tasks.filter(t => t.status === 'IN_PROGRESS' && t.agentWorkingStatus === 'CHATTING').length;
  const completedCount = tasks.filter(t => t.status === 'COMPLETED').length;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold font-rpg text-white tracking-wide">
              MANAJEMEN TASK AGENT
            </h2>
            <span className="text-xs font-pixel px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              SHEET 2: TASK
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Pantau status operasional pengerjaan task: <strong>WORKING</strong>, <strong>CHATTING</strong>, <strong>IDLE</strong>, dan <strong>COMPLETED</strong>.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#ff1e42] hover:bg-red-600 text-white font-rpg text-xs font-bold shadow-[0_0_15px_rgba(255,30,66,0.35)] transition-all duration-200 self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Buat Task Baru</span>
        </button>
      </div>

      {/* 4 Status Snapshot Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-cyan-500/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-950/90 border border-cyan-500/50 flex items-center justify-center text-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
              <Zap className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <span className="text-[10px] font-pixel text-slate-400 block">STATUS</span>
              <span className="text-xs font-bold font-rpg text-cyan-300">WORKING</span>
            </div>
          </div>
          <span className="text-lg font-pixel font-bold text-cyan-400">{workingCount}</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-purple-500/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-950/90 border border-purple-500/50 flex items-center justify-center text-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.3)]">
              <MessageSquare className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] font-pixel text-slate-400 block">STATUS</span>
              <span className="text-xs font-bold font-rpg text-purple-300">CHATTING</span>
            </div>
          </div>
          <span className="text-lg font-pixel font-bold text-purple-400">{chattingCount}</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-950/90 border border-emerald-500/50 flex items-center justify-center text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.3)]">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-pixel text-slate-400 block">STATUS</span>
              <span className="text-xs font-bold font-rpg text-emerald-300">COMPLETED</span>
            </div>
          </div>
          <span className="text-lg font-pixel font-bold text-emerald-400">{completedCount}</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center text-slate-400">
              <Coffee className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-pixel text-slate-400 block">STATUS</span>
              <span className="text-xs font-bold font-rpg text-slate-300">IDLE / STANDBY</span>
            </div>
          </div>
          <span className="text-lg font-pixel font-bold text-slate-400">Standby</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Cari Task ID, Agent, atau kata kunci..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#ff1e42]"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <select
            value={filterAgent}
            onChange={(e) => setFilterAgent(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300"
          >
            <option value="ALL">Semua Agent</option>
            <option value="Manager">AI Manager</option>
            <option value="Membership">Sales Membership</option>
            <option value="Promo">Sales Promo</option>
            <option value="Creative">Creative Agent</option>
            <option value="Customer">Customer Service</option>
            <option value="Support">Support Hub</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300"
          >
            <option value="ALL">Semua Status</option>
            <option value="WORKING">⚡ WORKING</option>
            <option value="CHATTING">💬 CHATTING</option>
            <option value="COMPLETED">✓ COMPLETED</option>
            <option value="PENDING">PENDING</option>
          </select>
        </div>
      </div>

      {/* Task Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#0b1122] text-slate-400 font-pixel text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">TASK ID</th>
                <th className="py-3.5 px-4">AGENT</th>
                <th className="py-3.5 px-4">STATUS AGENT</th>
                <th className="py-3.5 px-4">TASK</th>
                <th className="py-3.5 px-4">PRIORITY</th>
                <th className="py-3.5 px-4">CREATED AT</th>
                <th className="py-3.5 px-4">RESULT</th>
                <th className="py-3.5 px-4 text-right">AKSI KONTROL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 font-pixel">
                    Tidak ada task yang cocok dengan filter
                  </td>
                </tr>
              ) : (
                filteredTasks.map((t) => {
                  const effectiveStatus = t.status === 'COMPLETED' ? 'COMPLETED' : (t.agentWorkingStatus || 'WORKING');
                  const agStatusBadge = getAgentStatusBadge(effectiveStatus);

                  return (
                    <tr key={t.taskId} className="hover:bg-slate-800/50 transition-colors">
                      <td className="py-3 px-4 font-pixel text-[#ff1e42] font-semibold">
                        {t.taskId}
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-200 whitespace-nowrap">
                        {t.agent}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-[10px] font-pixel ${agStatusBadge.pill}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${agStatusBadge.dot}`} />
                          <span>{agStatusBadge.label}</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 max-w-xs font-medium text-slate-100">
                        {t.task}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full border text-[10px] font-pixel ${getPriorityBadge(t.priority)}`}>
                          {t.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 whitespace-nowrap text-[11px]">
                        {t.createdAt}
                      </td>
                      <td className="py-3 px-4 text-slate-300 text-[11px] max-w-xs truncate">
                        {t.result || '-'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        {t.status !== 'COMPLETED' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Toggle between WORKING and CHATTING */}
                            <button
                              onClick={() => onUpdateTaskStatus(t.taskId, 'IN_PROGRESS', t.agentWorkingStatus === 'CHATTING' ? 'WORKING' : 'CHATTING')}
                              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[9px] font-pixel transition-colors"
                              title="Ganti mode kerja antara WORKING dan CHATTING"
                            >
                              {t.agentWorkingStatus === 'CHATTING' ? '⚡ Set WORKING' : '💬 Set CHATTING'}
                            </button>

                            {/* Mark COMPLETED */}
                            <button
                              onClick={() => onUpdateTaskStatus(t.taskId, 'COMPLETED')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40 text-[10px] font-pixel transition-colors cursor-pointer"
                              title="Tandai task selesai (COMPLETED)"
                            >
                              ✓ Selesaikan
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-2">
                            <span className="text-emerald-400 font-pixel text-[10px] flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> COMPLETED
                            </span>
                            <button
                              onClick={() => onUpdateTaskStatus(t.taskId, 'IN_PROGRESS', 'WORKING')}
                              className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[9px] font-pixel text-slate-400 hover:text-white"
                              title="Buka kembali task"
                            >
                              Reopen
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0b1222] border-2 border-[#ff1e42]/60 rounded-2xl p-6 shadow-2xl relative">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-lg font-bold font-rpg text-white mb-1">
              Buat Task Baru untuk Agent
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Pilih status pengerjaan saat task aktif: <strong>WORKING</strong> (teknis/desain) atau <strong>CHATTING</strong> (WhatsApp/CS).
            </p>

            <form onSubmit={handleCreateTask} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-pixel mb-1">PILIH AGENT:</label>
                <select
                  value={agentName}
                  onChange={(e) => handleAgentSelectChange(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200"
                >
                  <option value="AI Manager">🧠 AI Manager</option>
                  <option value="Sales Membership">💰 Sales Membership</option>
                  <option value="Sales Promo">🔥 Sales Promo</option>
                  <option value="Creative Agent">🎨 Creative Agent</option>
                  <option value="Customer Service">🎧 Customer Service</option>
                  <option value="Support Hub">🛠️ Support Hub</option>
                </select>
              </div>

              {/* Status Pengerjaan Agent Selector */}
              <div>
                <label className="block text-slate-300 font-pixel mb-1.5">
                  STATUS PENGERJAAN SAAT TASK BERJALAN:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAgentWorkingStatus('WORKING')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-pixel text-[11px] transition-all cursor-pointer ${
                      agentWorkingStatus === 'WORKING'
                        ? 'bg-cyan-950/90 text-cyan-300 border-cyan-500 shadow-[0_0_12px_rgba(6,182,212,0.4)] font-bold'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-cyan-400" />
                    <span>⚡ WORKING</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setAgentWorkingStatus('CHATTING')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-pixel text-[11px] transition-all cursor-pointer ${
                      agentWorkingStatus === 'CHATTING'
                        ? 'bg-purple-950/90 text-purple-300 border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.4)] font-bold'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
                    <span>💬 CHATTING</span>
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  {agentWorkingStatus === 'WORKING'
                    ? '⚡ Mode pengerjaan: Mengetik coding/analisis/render video/broadcast.'
                    : '💬 Mode pengerjaan: Chat WhatsApp aktif dengan pelanggan/follow up VIP.'}
                </p>
              </div>

              <div>
                <label className="block text-slate-300 font-pixel mb-1">DESKRIPSI TASK:</label>
                <textarea
                  rows={3}
                  placeholder="Contoh: Follow up customer Kevin untuk paket promo diamond MLBB 9.9"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-[#ff1e42]"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-pixel mb-1">PRIORITAS (PRIORITY):</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200"
                >
                  <option value="URGENT">URGENT (Paling Mendesak)</option>
                  <option value="HIGH">HIGH (Tinggi)</option>
                  <option value="MEDIUM">MEDIUM (Normal)</option>
                  <option value="LOW">LOW (Rendah)</option>
                </select>
              </div>

              <div className="pt-3 flex gap-3">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#ff1e42] hover:bg-red-600 text-white font-rpg font-bold shadow-lg cursor-pointer"
                >
                  Delegasikan Task
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 text-slate-300 font-rpg font-semibold cursor-pointer"
                >
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

