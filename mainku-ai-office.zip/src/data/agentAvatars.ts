import ownerAvatar from '../assets/images/agent_owner_1788935173214.jpg';
import managerAvatar from '../assets/images/agent_manager_1788935139610.jpg';
import salesMembershipAvatar from '../assets/images/agent_sales_membership_1788935061748.jpg';
import salesPromoAvatar from '../assets/images/agent_sales_promo_1788935079173.jpg';
import creativeAvatar from '../assets/images/agent_creative_1788935098723.jpg';
import csAvatar from '../assets/images/agent_cs_1788935118700.jpg';

export const AGENT_AVATARS: Record<string, string> = {
  owner: ownerAvatar,
  ai_manager: managerAvatar,
  sales_membership: salesMembershipAvatar,
  sales_promo: salesPromoAvatar,
  creative_agent: creativeAvatar,
  customer_service: csAvatar,
  support_hub: managerAvatar,
};

export const getAgentAvatar = (id: string): string => {
  return AGENT_AVATARS[id] || salesMembershipAvatar;
};
