import { AgentInfo, ActivityItem, Customer, Task, PerformanceReport } from '../types';
import { AGENT_AVATARS } from './agentAvatars';

export const INITIAL_AGENTS: AgentInfo[] = [
  {
    id: 'ai_manager',
    name: 'AI Manager',
    role: 'Orchestrator & Strategy',
    icon: '🧠',
    deskColor: 'border-blue-500 shadow-blue-500/30',
    ledHex: '#3b82f6',
    status: 'WORKING',
    activityText: 'Menganalisis data customer & delegasi task baru',
    currentTask: 'Delegasi leads MLBB Whale ke Sales Membership',
    completedTasksToday: 18,
    avatarSeed: 'manager',
    avatarImage: AGENT_AVATARS.ai_manager,
    deskPosition: { row: 0, col: 0 }
  },
  {
    id: 'sales_membership',
    name: 'Sales Membership',
    role: 'VIP & High-Tier Conversion',
    icon: '💰',
    deskColor: 'border-amber-500 shadow-amber-500/30',
    ledHex: '#f59e0b',
    status: 'CHATTING',
    activityText: 'Follow up WhatsApp Sultan MLBB (VIP tier)',
    currentTask: 'Pitching Member Black Diamond ke Budi Whale',
    completedTasksToday: 12,
    avatarSeed: 'sales_vip',
    avatarImage: AGENT_AVATARS.sales_membership,
    deskPosition: { row: 0, col: 1 }
  },
  {
    id: 'sales_promo',
    name: 'Sales Promo',
    role: 'Flash Sale & Event Campaign',
    icon: '🔥',
    deskColor: 'border-[#ff1e42] shadow-[#ff1e42]/40',
    ledHex: '#ff1e42',
    status: 'IDLE',
    activityText: 'Standby jadwal Flash Sale Genshin Impact 18:00',
    currentTask: 'Menunggu slot promo gajian',
    completedTasksToday: 9,
    avatarSeed: 'promo',
    avatarImage: AGENT_AVATARS.sales_promo,
    deskPosition: { row: 0, col: 2 }
  },
  {
    id: 'creative_agent',
    name: 'Creative Agent',
    role: 'Banner & Copywriting',
    icon: '🎨',
    deskColor: 'border-teal-400 shadow-teal-400/30',
    ledHex: '#14b8a6',
    status: 'WORKING',
    activityText: 'Generate feed IG promo diamond MLBB 50% cash back',
    currentTask: 'Desain Banner Promo Weekend Party Free Fire',
    completedTasksToday: 14,
    avatarSeed: 'creative',
    avatarImage: AGENT_AVATARS.creative_agent,
    deskPosition: { row: 1, col: 0 }
  },
  {
    id: 'customer_service',
    name: 'Customer Service',
    role: 'Support 24/7 & Order Issues',
    icon: '🎧',
    deskColor: 'border-emerald-500 shadow-emerald-500/30',
    ledHex: '#10b981',
    status: 'CHATTING',
    activityText: 'Bantu verifikasi invoice pending order #MK-9921',
    currentTask: 'Live chat order Valorant Points via QRIS',
    completedTasksToday: 32,
    avatarSeed: 'cs',
    avatarImage: AGENT_AVATARS.customer_service,
    deskPosition: { row: 1, col: 1 }
  },
  {
    id: 'support_hub',
    name: 'Support Hub',
    role: 'API Provider & Server Monitor',
    icon: '🛠️',
    deskColor: 'border-orange-500 shadow-orange-500/30',
    ledHex: '#f97316',
    status: 'COMPLETED',
    activityText: 'Sinkronisasi stok voucher Google Play & Digiflazz OK',
    currentTask: 'Audit response time API Supplier Digiflazz',
    completedTasksToday: 24,
    avatarSeed: 'support',
    avatarImage: AGENT_AVATARS.support_hub,
    deskPosition: { row: 1, col: 2 }
  }
];

export const INITIAL_ACTIVITIES: ActivityItem[] = [
  {
    id: 'act-1',
    time: 'Baru saja',
    agentId: 'sales_membership',
    agentName: 'Sales Membership',
    activity: 'Menghubungi customer VIP via WhatsApp',
    customer: 'Kevin "Sultan" Pratama (MLBB)',
    status: 'CHATTING'
  },
  {
    id: 'act-2',
    time: '2 menit lalu',
    agentId: 'ai_manager',
    agentName: 'AI Manager',
    activity: 'Membuat task baru: Penawaran Tier Sultan Genshin',
    customer: 'Rian Genshin Whale',
    status: 'WORKING'
  },
  {
    id: 'act-3',
    time: '6 menit lalu',
    agentId: 'creative_agent',
    agentName: 'Creative Agent',
    activity: 'Membuat ide campaign "Gajian Top Up Party"',
    status: 'COMPLETED'
  },
  {
    id: 'act-4',
    time: '12 menit lalu',
    agentId: 'customer_service',
    agentName: 'Customer Service',
    activity: 'Menyelesaikan kendala top up delay server Moonton',
    customer: 'Deni Saputra',
    status: 'COMPLETED'
  },
  {
    id: 'act-5',
    time: '18 menit lalu',
    agentId: 'sales_promo',
    agentName: 'Sales Promo',
    activity: 'Broadcast kupon diskon 15% Free Fire ke 450 member',
    status: 'WORKING'
  },
  {
    id: 'act-6',
    time: '25 menit lalu',
    agentId: 'support_hub',
    agentName: 'Support Hub',
    activity: 'Health check latency API Top Up: 180ms (Normal)',
    status: 'COMPLETED'
  }
];

// Data format matching user's Google Sheet 1: CUSTOMER
export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'CUST-001',
    nameOfMember: 'Kevin "Sultan" Pratama',
    contact: '+6281299887766',
    tierCompetitor: 'VIP Codashop (Rp 15jt/bln)',
    customerStatus: 'Active',
    lastContact: 'Hari ini, 10:15 WIB',
    salesPriority: 'URGENT',
    aiRecommendation: 'Tawarkan Membership Black MAINku dengan cashback point 5% + VIP priority CS',
    followUpStatus: 'In Progress',
    favoriteGame: 'Mobile Legends',
    avgSpend: 'Rp 14.500.000'
  },
  {
    id: 'CUST-002',
    nameOfMember: 'Rian Genshin Whale',
    contact: '+6285711223344',
    tierCompetitor: 'Top Spender Unipin',
    customerStatus: 'Prospect',
    lastContact: 'Kemarin, 16:30 WIB',
    salesPriority: 'HIGH',
    aiRecommendation: 'Kirim paket Blessing of Welkin Moon bundling Genesis Crystal rate distributor',
    followUpStatus: 'Pending',
    favoriteGame: 'Genshin Impact',
    avgSpend: 'Rp 8.200.000'
  },
  {
    id: 'CUST-003',
    nameOfMember: 'Aldi "Headshot" Wijaya',
    contact: '+6281355443322',
    tierCompetitor: 'Casual Itemku',
    customerStatus: 'Active',
    lastContact: '06 Sep 2026',
    salesPriority: 'MEDIUM',
    aiRecommendation: 'Berikan kupon flash sale Free Fire Diamond bonus 140 DM',
    followUpStatus: 'Follow Up Scheduled',
    favoriteGame: 'Free Fire',
    avgSpend: 'Rp 1.850.000'
  },
  {
    id: 'CUST-004',
    nameOfMember: 'Jessica Valo Radiant',
    contact: '+6287899001122',
    tierCompetitor: 'Whale Tokopedia Gaming',
    customerStatus: 'Churn Risk',
    lastContact: '28 Agu 2026',
    salesPriority: 'HIGH',
    aiRecommendation: 'Ingatkan ada bundle skin Valorant Champions baru, berikan jaminan diskon MAINku lebih murah 4%',
    followUpStatus: 'Pending',
    favoriteGame: 'Valorant',
    avgSpend: 'Rp 6.300.000'
  },
  {
    id: 'CUST-005',
    nameOfMember: 'Gilang Honor of Kings',
    contact: '+6289633221100',
    tierCompetitor: 'Member Baru',
    customerStatus: 'Active',
    lastContact: '07 Sep 2026',
    salesPriority: 'LOW',
    aiRecommendation: 'Edukasi cara pakai promo voucher welcome reward di MAINku.com',
    followUpStatus: 'Deal Won',
    favoriteGame: 'Honor of Kings',
    avgSpend: 'Rp 950.000'
  }
];

// Data format matching user's Google Sheet 2: TASK
export const INITIAL_TASKS: Task[] = [
  {
    taskId: 'TSK-101',
    agent: 'Sales Membership',
    agentId: 'sales_membership',
    task: 'Follow-up Kevin Pratama untuk upgrade paket Member Sultan MAINku',
    priority: 'URGENT',
    status: 'IN_PROGRESS',
    createdAt: '08 Sep 2026 09:30',
    result: 'Customer merespons via WA, minta perbandingan rate dengan Codashop'
  },
  {
    taskId: 'TSK-102',
    agent: 'AI Manager',
    agentId: 'ai_manager',
    task: 'Scanning 50 customer dorman untuk re-engagement promo 9.9',
    priority: 'HIGH',
    status: 'IN_PROGRESS',
    createdAt: '08 Sep 2026 09:00',
    result: 'Ditemukan 18 player MLBB berpotensi kembali aktif'
  },
  {
    taskId: 'TSK-103',
    agent: 'Creative Agent',
    agentId: 'creative_agent',
    task: 'Buat 3 variasi banner story Instagram promo gajian game topup',
    priority: 'MEDIUM',
    status: 'COMPLETED',
    createdAt: '08 Sep 2026 08:15',
    result: 'Selesai: 3 file template Canva siap upload dengan tema neon cyberpunk'
  },
  {
    taskId: 'TSK-104',
    agent: 'Sales Promo',
    agentId: 'sales_promo',
    task: 'Set schedule flash sale midnight 9.9 di web MAINku.com',
    priority: 'HIGH',
    status: 'COMPLETED',
    createdAt: '07 Sep 2026 21:00',
    result: 'Sistem flash sale terpasang untuk 1000 kuota diamond MLBB'
  },
  {
    taskId: 'TSK-105',
    agent: 'Customer Service',
    agentId: 'customer_service',
    task: 'Penyelesaian refund order #MK-8871 kendala timeout Moonton',
    priority: 'URGENT',
    status: 'COMPLETED',
    createdAt: '08 Sep 2026 07:45',
    result: 'Dana sudah sukses dikembalikan via saldo MAINku + bonus 50 DM kompensasi'
  },
  {
    taskId: 'TSK-106',
    agent: 'Support Hub',
    agentId: 'support_hub',
    task: 'Backup log transaksi mingguan dan sinkronisasi saldo Digiflazz',
    priority: 'LOW',
    status: 'COMPLETED',
    createdAt: '08 Sep 2026 06:00',
    result: 'Database sync OK, sisa deposit supplier aman di atas Rp 25.000.000'
  }
];

// Data format matching user's Google Sheet 4: REPORTS
export const INITIAL_REPORTS: PerformanceReport[] = [
  {
    agentId: 'ai_manager',
    agentName: 'AI Manager',
    tasksCompleted: 45,
    leadsProcessed: 120,
    conversionRate: '88%',
    avgResponseTime: '1.2s',
    satisfactionScore: 98
  },
  {
    agentId: 'sales_membership',
    agentName: 'Sales Membership',
    tasksCompleted: 38,
    leadsProcessed: 54,
    conversionRate: '72%',
    avgResponseTime: '3.4m',
    satisfactionScore: 94
  },
  {
    agentId: 'sales_promo',
    agentName: 'Sales Promo',
    tasksCompleted: 29,
    leadsProcessed: 840,
    conversionRate: '31%',
    avgResponseTime: 'Instant',
    satisfactionScore: 91
  },
  {
    agentId: 'creative_agent',
    agentName: 'Creative Agent',
    tasksCompleted: 34,
    leadsProcessed: 18,
    conversionRate: '95%',
    avgResponseTime: '12m',
    satisfactionScore: 96
  },
  {
    agentId: 'customer_service',
    agentName: 'Customer Service',
    tasksCompleted: 88,
    leadsProcessed: 92,
    conversionRate: '99%',
    avgResponseTime: '45s',
    satisfactionScore: 97
  },
  {
    agentId: 'support_hub',
    agentName: 'Support Hub',
    tasksCompleted: 62,
    leadsProcessed: 1540,
    conversionRate: '99.9%',
    avgResponseTime: '200ms',
    satisfactionScore: 99
  }
];
