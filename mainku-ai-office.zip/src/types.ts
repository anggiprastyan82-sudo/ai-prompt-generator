export type AgentId = 
  | 'ai_manager'
  | 'sales_membership'
  | 'sales_promo'
  | 'creative_agent'
  | 'customer_service'
  | 'support_hub';

export type AgentStatus = 'IDLE' | 'THINKING' | 'WORKING' | 'CHATTING' | 'COMPLETED';

export type PriorityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';

export interface AgentInfo {
  id: AgentId;
  name: string;
  role: string;
  icon: string;
  deskColor: string; // Tailored LED color for desk
  ledHex: string;
  status: AgentStatus;
  activityText: string;
  currentTask?: string;
  completedTasksToday: number;
  avatarSeed: string;
  avatarImage?: string;
  deskPosition: { row: number; col: number };
}

export interface ActivityItem {
  id: string;
  time: string;
  agentId: AgentId;
  agentName: string;
  activity: string;
  customer?: string;
  status: AgentStatus;
}

export interface Customer {
  id: string;
  nameOfMember: string;
  contact: string;
  tierCompetitor: string; // e.g., 'VIP Codashop', 'Whale Unipin', 'Casual Player'
  customerStatus: 'Active' | 'Prospect' | 'Dormant' | 'Churn Risk';
  lastContact: string;
  salesPriority: 'URGENT' | 'HIGH' | 'MEDIUM' | 'LOW';
  aiRecommendation: string;
  followUpStatus: 'Pending' | 'In Progress' | 'Deal Won' | 'Follow Up Scheduled';
  favoriteGame?: string;
  avgSpend?: string;
}

export interface Task {
  taskId: string;
  agent: string;
  agentId: AgentId;
  task: string;
  priority: PriorityLevel;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  agentWorkingStatus?: AgentStatus;
  createdAt: string;
  result?: string;
}

export interface PerformanceReport {
  agentId: AgentId;
  agentName: string;
  tasksCompleted: number;
  leadsProcessed: number;
  conversionRate: string;
  avgResponseTime: string;
  satisfactionScore: number;
}

export type NavigationTab = 'home' | 'office' | 'tasks' | 'customers' | 'reports' | 'settings';
